import cv2
import numpy as np
import time
import torch
from ultralytics import YOLO
import sys
import os
from collections import deque

# GPU kullanımını optimize et
torch.backends.cudnn.benchmark = True
torch.backends.cudnn.deterministic = False

# YOLO modelini yükle (GPU kontrolü ve taşıma)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Cihaz: {device}")

# Model yolu ve yükleme
model_path = r"C:\Users\omerb\OneDrive\Masaüstü\yolov11\optuna_results\best.pt\weights\best.pt"
try:
    model = YOLO(model_path).to(device)
    print(f"Model başarıyla yüklendi: {model_path}")
except Exception as e:
    print(f"Model yükleme hatası: {e}")
    sys.exit(1)

# Video kaynağını aç
video_path = r"C:\Users\omerb\OneDrive\Masaüstü\yolov11\datasets\test\suf.mp4"
try:
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise Exception("Video dosyası açılamadı")
    print(f"Video başarıyla açıldı: {video_path}")
except Exception as e:
    print(f"Video açma hatası: {e}")
    sys.exit(1)

# Video özellikleri
original_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
original_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
fps_video = cap.get(cv2.CAP_PROP_FPS)
print(f"Orijinal video boyutu: {original_width}x{original_height}, FPS: {fps_video}")

# Çözünürlük ayarları
target_width = 1280
target_height = 720

# Performans ve takip parametreleri
conf_threshold = 0.35  # Güven eşiği
iou_threshold = 0.45   # IoU eşiği
detection_interval = 5  # Her kaç karede bir YOLO çalıştırılacak
search_expansion = 1.5  # Takip bölgesi genişletme katsayısı
max_tracking_failure = 10  # Maksimum takip başarısızlık sayısı
target_box_history_size = 10  # Son kutuların saklanacağı geçmişin boyutu

# Kilitlenme parametreleri
lock_duration = 4.0  # Kilitlenme için gereken süre (saniye)
required_area_ratio = 0.05  # Hedef boyutunun minimum oranı (%5)
lock_cooldown_duration = 1.0  # Bekleme süresi (saniye)

# Takip için değişkenler
current_box = None
is_tracking = False
tracking_id = 0
last_confidence = 0
frame_count = 0
tracking_failure_count = 0
target_box_history = deque(maxlen=target_box_history_size)

# Kilitlenme durumu değişkenleri
lock_start_time = None
tracking_start_time = None
successful_locks = 0
success_display_time = None
lock_cooldown_start_time = None

# FPS ve performans ölçümü
frame_times = deque(maxlen=30)  # Son 30 karenin işleme süreleri
detection_times = deque(maxlen=10)  # Son 10 tespit için geçen süreler
start_time = time.time()
prev_frame_time = start_time

def resize_frame(frame, target_width, target_height):
    """Kareyi hedef çözünürlüğe yeniden boyutlandırır"""
    return cv2.resize(frame, (target_width, target_height), interpolation=cv2.INTER_AREA)

def detect_uav(frame, conf_threshold):
    """YOLO modeli ile İHA tespiti yapar"""
    detection_start = time.time()
    results = model(frame, conf=conf_threshold, iou=iou_threshold)
    detection_time = time.time() - detection_start
    detection_times.append(detection_time)
    
    best_box = None
    best_conf = 0
    
    for result in results:
        boxes = result.boxes
        for box in boxes:
            conf = float(box.conf[0])
            if conf > best_conf:
                best_conf = conf
                x1, y1, x2, y2 = map(int, box.xyxy[0])
                best_box = [x1, y1, x2, y2]
                
    return best_box, best_conf, detection_time

def calculate_iou(box1, box2):
    """İki kutu arasındaki IoU (Intersection over Union) değerini hesaplar"""
    # Box koordinatları: [x1, y1, x2, y2]
    x1_1, y1_1, x2_1, y2_1 = box1
    x1_2, y1_2, x2_2, y2_2 = box2
    
    # Kesişim alanını hesapla
    x_left = max(x1_1, x1_2)
    y_top = max(y1_1, y1_2)
    x_right = min(x2_1, x2_2)
    y_bottom = min(y2_1, y2_2)
    
    if x_right < x_left or y_bottom < y_top:
        return 0.0  # Kesişim yok
    
    intersection_area = (x_right - x_left) * (y_bottom - y_top)
    
    # Her bir kutunun alanını hesapla
    box1_area = (x2_1 - x1_1) * (y2_1 - y1_1)
    box2_area = (x2_2 - x1_2) * (y2_2 - y1_2)
    
    # IoU hesapla
    iou = intersection_area / float(box1_area + box2_area - intersection_area)
    return iou

def get_expanded_search_area(box, frame_shape, expansion_factor=1.5):
    """Tespit edilen kutunun etrafında genişletilmiş bir arama alanı döndürür"""
    height, width = frame_shape[:2]
    x1, y1, x2, y2 = box
    
    # Kutu merkezi
    center_x = (x1 + x2) // 2
    center_y = (y1 + y2) // 2
    
    # Genişlik ve yükseklik
    box_width = x2 - x1
    box_height = y2 - y1
    
    # Genişletilmiş alan
    new_width = int(box_width * expansion_factor)
    new_height = int(box_height * expansion_factor)
    
    # Yeni koordinatlar (sınırlar içinde)
    new_x1 = max(0, center_x - new_width // 2)
    new_y1 = max(0, center_y - new_height // 2)
    new_x2 = min(width, center_x + new_width // 2)
    new_y2 = min(height, center_y + new_height // 2)
    
    return [new_x1, new_y1, new_x2, new_y2]

def smooth_box_prediction(current_box, history):
    """Önceki kutuları kullanarak yumuşatılmış bir kutu tahmini yapar"""
    if not history:
        return current_box
    
    # Son N kutuyu kullan, ağırlıklı ortalama hesapla
    x1s, y1s, x2s, y2s = [], [], [], []
    weights = []
    
    for i, box in enumerate(history):
        weight = (i + 1) / len(history)  # Daha yeni kutulara daha fazla ağırlık ver
        weights.append(weight)
        x1s.append(box[0] * weight)
        y1s.append(box[1] * weight)
        x2s.append(box[2] * weight)
        y2s.append(box[3] * weight)
    
    # Mevcut kutuya en yüksek ağırlık ver
    current_weight = 1.5
    weights.append(current_weight)
    x1s.append(current_box[0] * current_weight)
    y1s.append(current_box[1] * current_weight)
    x2s.append(current_box[2] * current_weight)
    y2s.append(current_box[3] * current_weight)
    
    # Ağırlıklı ortalama
    total_weight = sum(weights)
    x1 = int(sum(x1s) / total_weight)
    y1 = int(sum(y1s) / total_weight)
    x2 = int(sum(x2s) / total_weight)
    y2 = int(sum(y2s) / total_weight)
    
    return [x1, y1, x2, y2]

def draw_target_area(frame):
    """Hedef vuruş alanını çizer ve koordinatlarını döndürür"""
    frame_height, frame_width, _ = frame.shape
    top = int(frame_height * 0.10)
    bottom = int(frame_height * 0.90)
    left = int(frame_width * 0.25)
    right = int(frame_width * 0.75)
    cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 255), 2)
    return left, top, right, bottom

def calculate_average(deque_obj):
    """Verilen deque objesinin ortalamasını hesaplar"""
    if not deque_obj:
        return 0
    return sum(deque_obj) / len(deque_obj)

# Ana işleme döngüsü
try:
    while True:
        loop_start = time.time()
        
        # Kare oku
        ret, frame = cap.read()
        if not ret:
            print("Video akışı sona erdi veya okunamadı.")
            break
        
        # Kareyi yeniden boyutlandır
        frame = resize_frame(frame, target_width, target_height)
        
        # Hedef vuruş alanını çiz
        target_left, target_top, target_right, target_bottom = draw_target_area(frame)
        frame_center = (target_width // 2, target_height // 2)
        cv2.circle(frame, frame_center, 5, (0, 0, 255), -1)
        
        # Sağ üst köşeye "UFK Tespit ve Takip Sistemi" yazısını çiz
        cv2.putText(frame, "UFK", (target_width - 140, 55), cv2.FONT_HERSHEY_SIMPLEX, 2, (48, 117, 238), 8)
        cv2.putText(frame, "Tespit ve Takip", (target_width - 137, 78), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (48, 117, 238), 2)
        cv2.putText(frame, "Sistemi", (target_width - 135, 110), cv2.FONT_HERSHEY_SIMPLEX, 1, (48, 117, 238), 4)
        
        # Ham kare için kopya oluştur
        detection_frame = frame.copy()
        detection_time = 0
        
        # Tespit ve takip mantığı
        if frame_count % detection_interval == 0 or not is_tracking or tracking_failure_count > max_tracking_failure:
            # Tam kare üzerinde tespit yap
            detected_box, confidence, detection_time = detect_uav(detection_frame, conf_threshold)
            
            if detected_box and confidence >= conf_threshold:
                current_box = detected_box
                last_confidence = confidence
                is_tracking = True
                tracking_id = int(time.time()) % 1000  # Basit bir ID
                tracking_failure_count = 0
                
                # Kutu geçmişini güncelle
                target_box_history.append(current_box)
                
                # Yumuşatılmış kutu hesapla
                current_box = smooth_box_prediction(current_box, list(target_box_history)[:-1])
            else:
                tracking_failure_count += 1
                if tracking_failure_count > max_tracking_failure:
                    is_tracking = False
                    current_box = None
                    
        elif is_tracking and current_box:
            # Hedef takibini geliştirmek için genişletilmiş arama alanı kullan
            search_area = get_expanded_search_area(current_box, frame.shape, search_expansion)
            search_x1, search_y1, search_x2, search_y2 = search_area
            
            # Arama alanını çiz (opsiyonel, hata ayıklama için)
            # cv2.rectangle(frame, (search_x1, search_y1), (search_x2, search_y2), (255, 255, 0), 1)
            
            # Sadece arama alanında tespit yap
            search_region = detection_frame[search_y1:search_y2, search_x1:search_x2]
            if search_region.size > 0:  # Arama bölgesi geçerliyse
                detected_box, confidence, detection_time = detect_uav(search_region, conf_threshold)
                
                if detected_box and confidence >= conf_threshold:
                    # Arama bölgesindeki koordinatları orijinal çerçeveye dönüştür
                    x1, y1, x2, y2 = detected_box
                    detected_box = [x1 + search_x1, y1 + search_y1, x2 + search_x1, y2 + search_y1]
                    
                    # IoU hesapla
                    box_iou = calculate_iou(current_box, detected_box)
                    
                    if box_iou > 0.1:  # Minimum IoU eşiği
                        current_box = detected_box
                        last_confidence = confidence
                        tracking_failure_count = 0
                        target_box_history.append(current_box)
                        current_box = smooth_box_prediction(current_box, list(target_box_history)[:-1])
                    else:
                        tracking_failure_count += 1
                else:
                    tracking_failure_count += 1
        
        # Eğer hedef takip ediliyorsa
        object_center = None
        width = 0
        height = 0
        
        if is_tracking and current_box:
            x1, y1, x2, y2 = current_box
            object_center = ((x1 + x2) // 2, (y1 + y2) // 2)
            width = x2 - x1
            height = y2 - y1
            
            # Kutuyu çiz - takip durumuna göre renk seç
            if tracking_failure_count == 0:
                box_color = (0, 255, 0)  # Yeşil: güvenilir takip
            elif tracking_failure_count < max_tracking_failure // 2:
                box_color = (0, 255, 255)  # Sarı: az güvenilir
            else:
                box_color = (0, 165, 255)  # Turuncu: düşük güvenilir
            
            cv2.rectangle(frame, (x1, y1), (x2, y2), box_color, 3)
            
            # Tespit/takip durumu metnini göster
            if frame_count % detection_interval == 0:
                cv2.putText(frame, f"TESPIT EDILDI", (10, 30), 
                            cv2.FONT_HERSHEY_COMPLEX_SMALL, 0.8, (0, 255, 0), 1)
            else:
                cv2.putText(frame, f"TAKIP EDILIYOR (ID: {tracking_id})", (10, 30), 
                            cv2.FONT_HERSHEY_COMPLEX_SMALL, 0.8, (0, 255, 0), 1)
            
            cv2.putText(frame, f"Guven: {last_confidence:.2f}", (10, 50), 
                        cv2.FONT_HERSHEY_COMPLEX_SMALL, 0.8, (0, 255, 0), 1)
            
            # Hedefle merkez arasına çizgi çiz
            cv2.line(frame, frame_center, object_center, (0, 255, 0), 2, cv2.LINE_AA)
            
            # Hedef bilgilerini göster
            relative_x = object_center[0] - frame_center[0]
            relative_y = object_center[1] - frame_center[1]
            width_ratio = width / target_width
            height_ratio = height / target_height
            
            cv2.putText(frame, f"Hedef Konumu: {relative_x},{relative_y}", (10, 110),
                        cv2.FONT_HERSHEY_COMPLEX_SMALL, 0.8, (0, 255, 0), 1)
            cv2.putText(frame, f"Hedef Boyutu: W:{width_ratio:.0%},H:{height_ratio:.0%}", (10, 130),
                        cv2.FONT_HERSHEY_COMPLEX_SMALL, 0.8, (0, 255, 0), 1)
            
            # Kilitlenme mantığı
            if (
                target_left < object_center[0] < target_right and
                target_top < object_center[1] < target_bottom and
                (width / target_width >= required_area_ratio or height / target_height >= required_area_ratio)
            ):
                # Eğer bekleme süresi aktifse
                if lock_cooldown_start_time and time.time() - lock_cooldown_start_time < lock_cooldown_duration:
                    countdown_text = "BEKLENIYOR"
                    cv2.putText(frame, countdown_text, ((target_left + target_right) // 2 - 100, target_top - 10),
                                cv2.FONT_HERSHEY_TRIPLEX, 0.8, (0, 255, 255), 1)
                else:
                    if lock_start_time is None:
                        lock_start_time = time.time()
                        tracking_start_time = time.time()
                    else:
                        elapsed_time = time.time() - lock_start_time
                        tracking_time = time.time() - tracking_start_time
                        countdown = lock_duration - elapsed_time
                        countdown_text = f"{max(countdown, 0):.0f}"
                        cv2.putText(frame, countdown_text, ((target_left + target_right) // 2, target_top - 10),
                                    cv2.FONT_HERSHEY_TRIPLEX, 0.8, (0, 255, 255), 1)
                        cv2.putText(frame, f"Takip Suresi: {tracking_time:.2f}", (10, 170),
                                    cv2.FONT_HERSHEY_COMPLEX_SMALL, 0.8, (0, 255, 0), 1)
                        
                        if elapsed_time >= lock_duration:
                            successful_locks += 1
                            success_display_time = time.time()
                            lock_start_time = None
                            lock_cooldown_start_time = time.time()
            else:
                # Kilitlenme şartları bozulursa sayaçlar sıfırlanır
                lock_start_time = None
                tracking_start_time = None
            
            # Başarılı kilitlenme yazısı
            if success_display_time and (time.time() - success_display_time <= 0.8):
                cv2.putText(frame, ">>>BASARILIYLA KILITLENILDI<<<", ((target_left + target_right) // 2 - 245, target_top + 25),
                            cv2.FONT_HERSHEY_COMPLEX_SMALL, 1.2, (0, 255, 0), 1)
            elif success_display_time and (time.time() - success_display_time > 1):
                success_display_time = None
            
            cv2.putText(frame, f"Basarili Kilitlenme: {successful_locks}", (10, 190),
                        cv2.FONT_HERSHEY_COMPLEX_SMALL, 0.8, (0, 255, 0), 1)
        
        # FPS ve performans bilgilerini hesapla ve göster
        frame_time = time.time() - loop_start
        frame_times.append(frame_time)
        avg_frame_time = calculate_average(frame_times)
        avg_fps = 1.0 / avg_frame_time if avg_frame_time > 0 else 0
        avg_detection_time = calculate_average(detection_times) * 1000  # milisaniye cinsinden
        
        cv2.putText(frame, f"FPS: {avg_fps:.1f}", (10, 70), cv2.FONT_HERSHEY_COMPLEX_SMALL, 0.8, (0, 255, 0), 1)
        cv2.putText(frame, f"Tespit Suresi: {detection_time*1000:.1f}ms", (10, 90), 
                    cv2.FONT_HERSHEY_COMPLEX_SMALL, 0.8, (0, 255, 0), 1)
        
        # GPU bilgisini göster (opsiyonel)
        if device.type == "cuda":
            gpu_mem = torch.cuda.memory_allocated() / 1024**2
            cv2.putText(frame, f"GPU: {gpu_mem:.1f}MB", (10, 210), 
                        cv2.FONT_HERSHEY_COMPLEX_SMALL, 0.8, (0, 255, 0), 1)
        
        # Çerçeveyi göster
        cv2.imshow("UFK Tespit ve Takip Sistemi", frame)
        
        # Çıkış için 'q' tuşu kontrolü
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
        
        frame_count += 1
        
except Exception as e:
    print(f"Hata oluştu: {e}")
    import traceback
    traceback.print_exc()
finally:
    # Kaynakları serbest bırak
    cap.release()
    cv2.destroyAllWindows()
    print(f"Toplam işlenen kare sayısı: {frame_count}")
    print(f"Toplam çalışma süresi: {time.time() - start_time:.2f} saniye")
    print(f"Ortalama FPS: {frame_count / (time.time() - start_time):.2f}")