import cv2
import numpy as np
import time
from ultralytics import YOLO
import torch

# YOLO modelini yükle (GPU kontrolü ve taşıma)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")  # GPU kullanımı kontrolü
model = YOLO(r"C:\Users\omerb\OneDrive\Masaüstü\yolov11\runs\detect\train\weights\best.pt").to(device)  # Modeli GPU'ya taşı

# Video kaynağını aç (0: web kamera, ya da video dosyası)
video_path = r"C:\Users\omerb\OneDrive\Masaüstü\yolov11\datasets\test\uav1.mp4"  # Video dosyasının tam yolu
cap = cv2.VideoCapture(video_path)

# Video çözünürlüğünü kontrol et ve yeniden ölçekle
target_width = 1280  # İstediğiniz genişlik
target_height = 720  # İstediğiniz yükseklik

def resize_frame(frame, target_width, target_height):
    """
    Videoyu belirtilen çözünürlüğe yeniden boyutlandırır.
    """
    return cv2.resize(frame, (target_width, target_height), interpolation=cv2.INTER_LINEAR)  # Daha hızlı boyutlandırma

# Kilitlenme ve takip değişkenleri
lock_start_time = None
countdown_start_time = None
countdown_duration = 4  # Geri sayım süresi (saniye)
successful_locks = 0
tracking_time = 0
tracking_start_time = None
target_locked = False

# FPS hesaplaması için zaman değişkenleri
prev_time = time.time()

# Nesne kilitlenme alanını kontrol eden fonksiyon
def is_within_bounds(frame, box, min_area_ratio=0.05):
    frame_height, frame_width, _ = frame.shape
    x1, y1, x2, y2 = map(int, box.xyxy[0])
    obj_area = (x2 - x1) * (y2 - y1)
    frame_area = frame_width * frame_height
    area_ratio = obj_area / frame_area
    return area_ratio >= min_area_ratio

# Hedef vuruş alanını çizen fonksiyon
def draw_target_area(frame):
    frame_height, frame_width, _ = frame.shape
    top = int(frame_height * 0.10)  # Üstten %10
    bottom = int(frame_height * 0.90)  # Alttan %10
    left = int(frame_width * 0.25)  # Soldan %25
    right = int(frame_width * 0.75)  # Sağdan %25
    cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 255), 2)  # Sarı alan
    return left, top, right, bottom

# Ana döngü
while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    # Çözünürlüğü yeniden boyutlandır
    frame = resize_frame(frame, target_width, target_height)

    # FPS hesapla
    current_time = time.time()
    fps = int(1 / (current_time - prev_time))
    prev_time = current_time

    # Hedef vuruş alanını çiz
    target_left, target_top, target_right, target_bottom = draw_target_area(frame)

    # Tam merkeze kırmızı nokta yerleştir
    frame_center = (target_width // 2, target_height // 2)
    cv2.circle(frame, frame_center, 7, (0, 0, 255), -1)  # Kırmızı nokta biraz büyütüldü

    # YOLO ile tahmin yap
    results = model(frame)

    # En yüksek doğruluk oranına sahip nesneyi bul
    highest_confidence = 0
    best_box = None
    for result in results:
        boxes = result.boxes
        for box in boxes:
            conf = box.conf[0]  # Güven puanı
            if conf > highest_confidence:
                highest_confidence = conf
                best_box = box

    if best_box:
        # Nesne merkezi ve boyutunu hesapla
        x1, y1, x2, y2 = map(int, best_box.xyxy[0])  # Koordinatlar
        object_center = ((x1 + x2) // 2, (y1 + y2) // 2)
        obj_area = (x2 - x1) * (y2 - y1)
        frame_area = target_width * target_height
        area_ratio = obj_area / frame_area * 100

        # Geri sayım ve kilitlenme kontrolü
        if target_left <= object_center[0] <= target_right and target_top <= object_center[1] <= target_bottom:
            if countdown_start_time is None:
                countdown_start_time = time.time()
            elif time.time() - countdown_start_time >= countdown_duration:
                target_locked = True
                successful_locks += 1
                countdown_start_time = None
        else:
            countdown_start_time = None

        # Takip süresi
        if target_locked:
            if tracking_start_time is None:
                tracking_start_time = time.time()
            tracking_time = int(time.time() - tracking_start_time)

        # AH kutusu üzerine geri sayım
        if countdown_start_time is not None:
            remaining_time = countdown_duration - int(time.time() - countdown_start_time)
            cv2.putText(frame, f"Geri Sayim: {remaining_time}", (x1 + (x2 - x1) // 2, y1 - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)

        # AV alanı üzerine başarılı kilitlenme mesajı
        if target_locked:
            cv2.putText(frame, ">>>KILITLENME BASARILI<<<", (target_width // 2 - 150, target_height - 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)

        # Sol üst köşe yazıları
        cv2.putText(frame, "HEDEF TESPIT EDILDI", (10, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
        cv2.putText(frame, f"GUVEN DEGERI: {highest_confidence:.2f}", (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 0.8,
                    (255, 255, 255), 2)
        cv2.putText(frame, f"FPS: {fps}", (10, 80), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
        cv2.putText(frame, f"HEDEFIN KONUMU: {object_center[0]} {object_center[1]}", (10, 120),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
        cv2.putText(frame, f"HEDEF BOYUTU: {area_ratio:.2f}%", (10, 150), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255),
                    2)
        cv2.putText(frame, f"TAKIP SURESI: {tracking_time}s", (10, 180), cv2.FONT_HERSHEY_SIMPLEX, 0.8,
                    (255, 255, 255), 2)
        cv2.putText(frame, f"BASARILI KILITLENME: {successful_locks}", (10, 210), cv2.FONT_HERSHEY_SIMPLEX, 0.8,
                    (255, 255, 255), 2)
    else:
        # Hedef tespit edilmediyse
        cv2.putText(frame, "HEDEF ARANIYOR", (10, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)

    # Çerçeveyi göster
    cv2.imshow("Frame", frame)

    # Çıkış için 'q' tuşuna bas
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()