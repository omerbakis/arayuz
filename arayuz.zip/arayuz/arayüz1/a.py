import cv2
import numpy as np
import time
from ultralytics import YOLO
import torch

# YOLO modelini yükle (GPU kontrolü ve taşıma)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")  # GPU kullanımı kontrolü
model = YOLO(r"C:\Users\omerb\OneDrive\Masaüstü\yolov11\runs\detect\train\weights\best.pt").to(device)  # Modeli GPU'ya taşı

# Video kaynağını aç (0: web kamera, ya da video dosyası)
video_path = r"C:\Users\omerb\OneDrive\Masaüstü\yolov11\datasets\test\uav1.mp4"
cap = cv2.VideoCapture(video_path)

# Video çözünürlüğünü kontrol et ve yeniden ölçekle
target_width = 1280
target_height = 720

def resize_frame(frame, target_width, target_height):
    return cv2.resize(frame, (target_width, target_height), interpolation=cv2.INTER_LINEAR)

# Kilitlenme ve takip ile ilgili değişkenler
lock_start_time = None
successful_locks = 0  # Başarılı kilitlenme sayısı
prev_time = time.time()

# Ana döngü
while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    frame = resize_frame(frame, target_width, target_height)
    current_time = time.time()
    fps = int(1 / (current_time - prev_time))
    prev_time = current_time

    # Çerçeve ve hedef alanı
    frame_height, frame_width, _ = frame.shape
    target_left = int(frame_width * 0.25)
    target_right = int(frame_width * 0.75)
    target_top = int(frame_height * 0.10)
    target_bottom = int(frame_height * 0.90)
    cv2.rectangle(frame, (target_left, target_top), (target_right, target_bottom), (0, 255, 255), 2)  # Sarı alan

    # Tam merkeze kırmızı nokta
    frame_center = (target_width // 2, target_height // 2)
    cv2.circle(frame, frame_center, 7, (0, 0, 255), -1)

    # YOLO ile tahmin yap
    results = model(frame)

    # Hedef bilgisi
    target_detected = False
    highest_confidence = 0
    best_box = None
    target_position = (0, 0)
    target_size = 0

    for result in results:
        boxes = result.boxes
        for box in boxes:
            conf = box.conf[0]  # Güven puanı
            if conf > highest_confidence:
                highest_confidence = conf
                best_box = box

    # Eğer hedef bulunduysa işleme al
    if best_box:
        target_detected = True
        x1, y1, x2, y2 = map(int, best_box.xyxy[0])
        target_position = ((x1 + x2) // 2, (y1 + y2) // 2)
        target_size = ((x2 - x1) * (y2 - y1)) / (frame_width * frame_height) * 100

        # Kilitlenme şartlarını kontrol et
        if (target_top < target_position[1] < target_bottom and
                target_left < target_position[0] < target_right and
                target_size >= 5):  # %5'lik alan şartı
            if lock_start_time is None:
                lock_start_time = current_time  # Kilitlenme süresini başlat
            elif current_time - lock_start_time >= 4:  # 4 saniye sabit kalma kontrolü
                successful_locks += 1
                lock_start_time = None
                cv2.putText(frame, ">>> KILITLENME BASARILI <<<",
                            ((target_left + target_right) // 2 - 150, target_bottom + 30),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
        else:
            lock_start_time = None  # Şartlar sağlanmazsa sıfırla

        # Çizim
        object_center = ((x1 + x2) // 2, (y1 + y2) // 2)
        cv2.line(frame, frame_center, object_center, (255, 0, 0), 3, cv2.LINE_AA)  # Çizgi
        cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)  # Çerçeve

    # Sol üst köşe yazıları
    if target_detected:
        cv2.putText(frame, "HEDEF TESPIT EDILDI", (10, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
        cv2.putText(frame, f"GUVEN DEGERI: {highest_confidence:.2f}", (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
    else:
        cv2.putText(frame, "HEDEF ARANIYOR", (10, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)

    cv2.putText(frame, f"FPS: {fps}", (10, 80), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)

    # Hedefin konumu ve boyutu
    cv2.putText(frame, f"HEDEFIN KONUMU: {target_position[0] - frame_center[0]} {target_position[1] - frame_center[1]}",
                (10, 130), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
    cv2.putText(frame, f"HEDEF BOYUTU: {target_size:.2f}%", (10, 160), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)

    # Başarılı kilitlenme sayısı
    cv2.putText(frame, f"BASARILI KILITLENME: {successful_locks}", (10, 190), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)

    # Çerçeveyi göster
    cv2.imshow("Frame", frame)

    # Çıkış için 'q' tuşuna bas
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
