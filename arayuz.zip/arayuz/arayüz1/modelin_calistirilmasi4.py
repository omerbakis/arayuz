import cv2
import numpy as np
import time
from ultralytics import YOLO
import torch

# YOLO modelini yükle (GPU kontrolü ve taşıma)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")  # GPU kullanımı kontrolü
model = YOLO(r"C:\Users\omerb\OneDrive\Masaüstü\yolov11\runs\detect\train\weights\best.pt").to(device)  # Modeli GPU'ya taşı

# Video kaynağını aç (0: web kamera, ya da video dosyası)
video_path = r"C:\Users\omerb\OneDrive\Masaüstü\yolov11\datasets\test\uav1.mp4"  # Video dosyasının tam yolu
cap = cv2.VideoCapture(video_path)

# Video çözünürlüğünü kontrol et ve yeniden ölçekle
target_width = 1280  # İstediğiniz genişlik
target_height = 720  # İstediğiniz yükseklik

def resize_frame(frame, target_width, target_height):
    """
    Videoyu belirtilen çözünürlüğe yeniden boyutlandırır.
    """
    return cv2.resize(frame, (target_width, target_height), interpolation=cv2.INTER_LINEAR)  # Daha hızlı boyutlandırma

# Kilitlenme için zaman ve durum değişkenleri
lock_start_time = None
lock_duration = 4  # Kilitlenme için gereken süre (saniye)

# FPS hesaplaması için zaman değişkenleri
prev_time = time.time()

# Nesne kilitlenme alanını kontrol eden fonksiyon
def is_within_bounds(frame, box, min_area_ratio=0.05):
    frame_height, frame_width, _ = frame.shape
    x1, y1, x2, y2 = map(int, box.xyxy[0])
    obj_area = (x2 - x1) * (y2 - y1)
    frame_area = frame_width * frame_height 
    area_ratio = obj_area / frame_area
    return area_ratio >= min_area_ratio

# Hedef vuruş alanını çizen fonksiyon
def draw_target_area(frame):
    frame_height, frame_width, _ = frame.shape
    top = int(frame_height * 0.10)  # Üstten %10
    bottom = int(frame_height * 0.90)  # Alttan %10
    left = int(frame_width * 0.25)  # Soldan %25
    right = int(frame_width * 0.75)  # Sağdan %25
    cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 255), 2)  # Sarı alan
    return left, top, right, bottom

# Ana döngü
while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    # Çözünürlüğü yeniden boyutlandır
    frame = resize_frame(frame, target_width, target_height)

    # FPS hesapla
    current_time = time.time()
    fps = int(1 / (current_time - prev_time))
    prev_time = current_time

    # Hedef vuruş alanını çiz
    target_left, target_top, target_right, target_bottom = draw_target_area(frame)

    # Tam merkeze kırmızı nokta yerleştir
    frame_center = (target_width // 2, target_height // 2)
    cv2.circle(frame, frame_center, 7, (0, 0, 255), -1)  # Kırmızı nokta biraz büyütüldü

    # YOLO ile tahmin yap
    results = model(frame)

    # En yüksek doğruluk oranına sahip nesneyi bul
    highest_confidence = 0
    best_box = None
    for result in results:
        boxes = result.boxes
        for box in boxes:
            conf = box.conf[0]  # Güven puanı
            if conf > highest_confidence:
                highest_confidence = conf
                best_box = box

    # En yüksek doğruluk oranına sahip nesneye işlem yap
    if best_box:
        x1, y1, x2, y2 = map(int, best_box.xyxy[0])  # Koordinatlar
        object_center = ((x1 + x2) // 2, (y1 + y2) // 2)

        # Kırmızı noktadan nesne merkezine mavi çizgi çiz
        cv2.line(frame, frame_center, object_center, (255, 0, 0), 2, cv2.LINE_AA)

        # Koordinatları yazdır
        cv2.putText(frame, f"X: {object_center[0]}", (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
        cv2.putText(frame, f"Y: {object_center[1]}", (10, 80), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)

        # Algılanan nesne çerçevesini çiz
        cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
        cv2.putText(frame, f"Confidence: {highest_confidence:.2f}", (x1, y1 - 10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

    # Sağ üst köşeye "UFK Tespit ve Takip Sistemi" yazısı
    cv2.putText(frame, "UFK Tespit ve Takip Sistemi", (target_width - 280, 20),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 165, 255), 2)

    # Sol üst köşeye FPS yazısı
    cv2.putText(frame, f"FPS: {fps}", (10, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)

    # Çerçeveyi göster
    cv2.imshow("Frame", frame)

    # Çıkış için 'q' tuşuna bas
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Kaynakları serbest bırak
cap.release()
cv2.destroyAllWindows()