import cv2
import numpy as np
import time
from ultralytics import YOLO
import torch

# YOLO modelini yükle (GPU kontrolü ve taşıma)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")  # GPU kullanımı kontrolü
model = YOLO(r"C:\Users\omerb\OneDrive\Masaüstü\yolov11\runs\detect\train\weights\best.pt").to(device)  # Modeli GPU'ya taşı

# Video kaynağını aç (0: web kamera, ya da video dosyası)
video_path = r"C:\Users\omerb\OneDrive\Masaüstü\yolov11\datasets\test\uav1.mp4"  # Video dosyasının tam yolu
cap = cv2.VideoCapture(video_path)

# Video çözünürlüğünü kontrol et ve yeniden ölçekle
target_width = 1280  # İstediğiniz genişlik
target_height = 720  # İstediğiniz yükseklik

def resize_frame(frame, target_width, target_height):
    """
    Videoyu belirtilen çözünürlüğe yeniden boyutlandırır.
    """
    return cv2.resize(frame, (target_width, target_height), interpolation=cv2.INTER_LINEAR)  # Daha hızlı boyutlandırma

# Kilitlenme için zaman ve durum değişkenleri
lock_start_time = None
lock_duration = 4  # Kilitlenme için gereken süre (saniye)
lock_status = False
lock_success = False

# FPS hesaplaması için zaman değişkenleri
prev_time = time.time()

# Hedef bilgilerini göstermek için değişkenler
target_detected = "Edilmedi"
confidence_score = 0.0
target_position = (0, 0)
target_size = (0, 0)
target_track_time = 0.0

# Ana döngü
while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    # Çözünürlüğü yeniden boyutlandır
    frame = resize_frame(frame, target_width, target_height)

    # FPS hesapla
    current_time = time.time()
    fps = int(1 / (current_time - prev_time))
    prev_time = current_time

    # YOLO ile tahmin yap
    results = model(frame)

    # En yüksek doğruluk oranına sahip nesneyi bul
    highest_confidence = 0
    best_box = None
    for result in results:
        boxes = result.boxes
        for box in boxes:
            conf = box.conf[0]  # Güven puanı
            if conf > highest_confidence:
                highest_confidence = conf
                best_box = box

    # En yüksek doğruluk oranına sahip nesneye işlem yap
    if best_box:
        x1, y1, x2, y2 = map(int, best_box.xyxy[0])  # Koordinatlar
        target_detected = "Edildi"
        confidence_score = highest_confidence
        target_position = ((x1 + x2) // 2, (y1 + y2) // 2)
        target_size = (x2 - x1, y2 - y1)

        # Algılanan nesne çerçevesini çiz
        cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)

        # Kilitlenme kontrolü
        if lock_start_time is None:
            lock_start_time = current_time

        elif current_time - lock_start_time >= lock_duration:
            lock_success = True
    else:
        target_detected = "Edilmedi"
        confidence_score = 0.0
        target_position = (0, 0)
        target_size = (0, 0)
        lock_start_time = None
        lock_success = False

    # Sol üst köşeye bilgileri yazdır
    info_lines = [
        f"HEDEF TESPİT: {target_detected}",
        f"Güven Puanı: {confidence_score:.2f}",
        f"FPS: {fps}",
        f"Hedef Konumu: X={target_position[0]} Y={target_position[1]}",
        f"Hedef Boyutu: {target_size}",
        f"Takip Süresi: {int(current_time - lock_start_time) if lock_start_time else 0}s",
        f"BAŞARILI KİLİTLENME: {'EVET' if lock_success else 'HAYIR'}"
    ]

    for i, line in enumerate(info_lines):
        cv2.putText(frame, line, (10, 30 + i * 20), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)

    # Çerçeveyi göster
    cv2.imshow("Frame", frame)

    # Çıkış için 'q' tuşuna bas
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Kaynakları serbest bırak
cap.release()
cv2.destroyAllWindows()
