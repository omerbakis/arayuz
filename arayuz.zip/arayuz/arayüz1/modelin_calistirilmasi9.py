import cv2
import numpy as np
import time
from ultralytics import YOLO
import torch

# YOLO modelini yükle (GPU kontrolü ve taşıma)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")  # GPU kullanımı kontrolü
model = YOLO(r"C:\Users\omerb\OneDrive\Masaüstü\yolov11\runs\detect\train\weights\best.pt").to(device)  # Modeli GPU'ya taşı

# Video kaynağını aç (0: web kamera, ya da video dosyası)
video_path = r"C:\Users\omerb\OneDrive\Masaüstü\yolov11\datasets\test\uav1.mp4"  # Video dosyasının tam yolu
cap = cv2.VideoCapture(video_path)

# Video çözünürlüğünü kontrol et ve yeniden ölçekle
target_width = 1280  # İstediğiniz genişlik
target_height = 720  # İstediğiniz yükseklik

def resize_frame(frame, target_width, target_height):
    """
    Videoyu belirtilen çözünürlüğe yeniden boyutlandırır.
    """
    return cv2.resize(frame, (target_width, target_height), interpolation=cv2.INTER_LINEAR)  # Daha hızlı boyutlandırma

# Kilitlenme için zaman ve durum değişkenleri
lock_start_time = None
lock_duration = 4  # Kilitlenme için gereken süre (saniye)
lock_success_count = 0  # Başarılı kilitlenme sayacı

# FPS hesaplaması için zaman değişkenleri
prev_time = time.time()

# Nesne kilitlenme alanını kontrol eden fonksiyon
def is_within_bounds(frame, box, min_area_ratio=0.05):
    frame_height, frame_width, _ = frame.shape
    x1, y1, x2, y2 = map(int, box.xyxy[0])
    obj_area = (x2 - x1) * (y2 - y1)
    frame_area = frame_width * frame_height
    area_ratio = obj_area / frame_area
    return area_ratio >= min_area_ratio

# Hedef vuruş alanını çizen fonksiyon
def draw_target_area(frame):
    frame_height, frame_width, _ = frame.shape
    top = int(frame_height * 0.10)  # Üstten %10
    bottom = int(frame_height * 0.90)  # Alttan %10
    left = int(frame_width * 0.25)  # Soldan %25
    right = int(frame_width * 0.75)  # Sağdan %25
    cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 255), 2)  # Sarı alan
    return left, top, right, bottom

# Ana döngü
tracking_start_time = None  # Takip süresi için başlangıç zamanı
while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    # Çözünürlüğü yeniden boyutlandır
    frame = resize_frame(frame, target_width, target_height)

    # FPS hesapla
    current_time = time.time()
    fps = int(1 / (current_time - prev_time))
    prev_time = current_time

    # Hedef vuruş alanını çiz
    target_left, target_top, target_right, target_bottom = draw_target_area(frame)

    # Tam merkeze kırmızı nokta yerleştir
    frame_center = (target_width // 2, target_height // 2)
    cv2.circle(frame, frame_center, 7, (0, 0, 255), -1)  # Kırmızı nokta biraz büyütüldü

    # YOLO ile tahmin yap
    results = model(frame)

    # En yüksek doğruluk oranına sahip nesneyi bul
    highest_confidence = 0
    best_box = None
    for result in results:
        boxes = result.boxes
        for box in boxes:
            conf = box.conf[0]  # Güven puanı
            if conf > highest_confidence:
                highest_confidence = conf
                best_box = box

    # Sol üst köşe bilgileri
    if best_box:
        x1, y1, x2, y2 = map(int, best_box.xyxy[0])  # Koordinatlar
        object_center = ((x1 + x2) // 2, (y1 + y2) // 2)
        object_width = ((x2 - x1) / target_width) * 100  # Hedef boyutu yüzdesi

        # Hedef tespit edildi
        cv2.putText(frame, "HEDEF TESPIT EDILDI", (10, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
        cv2.putText(frame, f"GÜVEN DEĞERI: {highest_confidence:.2f}", (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
        cv2.putText(frame, f"FPS: {fps}", (10, 80), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
        cv2.putText(frame, f"HEDEFIN KONUMU: {object_center[0] - frame_center[0]} {object_center[1] - frame_center[1]}", (10, 140), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
        cv2.putText(frame, f"HEDEF BOYUTU: {object_width:.2f}%", (10, 170), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)

        if tracking_start_time is not None:
            tracking_duration = current_time - tracking_start_time
            cv2.putText(frame, f"TAKIP SURESI: {tracking_duration:.2f}", (10, 200), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
        else:
            tracking_start_time = current_time

        # Kilitlenme koşulları kontrolü
        if is_within_bounds(frame, best_box):
            if lock_start_time is None:
                lock_start_time = time.time()
            elapsed_time = time.time() - lock_start_time
            remaining_time = max(0, int(lock_duration - elapsed_time))
            if remaining_time > 0:
                cv2.putText(frame, f"{remaining_time}", (x1 + (x2 - x1) // 2, y1 - 20), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
            else:
                lock_success_count += 1
                cv2.putText(frame, ">>> KILITLENME BASARILI <<<", (target_left + (target_right - target_left) // 2 - 100, target_top + 20), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
                lock_start_time = None
    else:
        cv2.putText(frame, "HEDEF ARANIYOR", (10, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
        tracking_start_time = None
        lock_start_time = None

    # Başarılı kilitlenme sayısı
    cv2.putText(frame, f"BASARILI KILITLENME: {lock_success_count}", (10, 230), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)

    # Çerçeveyi göster
    cv2.imshow("Frame", frame)

    # Çıkış için 'q' tuşuna bas
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Kaynakları serbest bırak
cap.release()
cv2.destroyAllWindows()