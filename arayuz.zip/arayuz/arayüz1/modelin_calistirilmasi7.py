import cv2
import numpy as np
import time
from ultralytics import YOLO
import torch

# YOLO modelini yükle (GPU kontrolü ve taşıma)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")  # GPU kullanımı kontrolü
model = YOLO(r"C:\Users\omerb\OneDrive\Masaüstü\yolov11\runs\detect\train\weights\best.pt").to(device)  # Modeli GPU'ya taşı

# Video kaynağını aç (0: web kamera, ya da video dosyası)
video_path = r"C:\Users\omerb\OneDrive\Masaüstü\yolov11\datasets\test\uav1.mp4"  # Video dosyasının tam yolu
cap = cv2.VideoCapture(video_path)

# Video çözünürlüğünü kontrol et ve yeniden ölçekle
target_width = 1280  # İstediğiniz genişlik
target_height = 720  # İstediğiniz yükseklik

# Başlangıç değişkenleri
lock_start_time = None
lock_duration = 4  # Kilitlenme için gereken süre (saniye)
countdown = 4
successful_locks = 0
tracking_time = 0
tracking_start_time = None

def resize_frame(frame, target_width, target_height):
    """
    Videoyu belirtilen çözünürlüğe yeniden boyutlandırır.
    """
    return cv2.resize(frame, (target_width, target_height), interpolation=cv2.INTER_LINEAR)  # Daha hızlı boyutlandırma

def draw_target_area(frame):
    frame_height, frame_width, _ = frame.shape
    top = int(frame_height * 0.10)  # Üstten %10
    bottom = int(frame_height * 0.90)  # Alttan %10
    left = int(frame_width * 0.25)  # Soldan %25
    right = int(frame_width * 0.75)  # Sağdan %25
    cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 255), 2)  # Sarı alan
    return left, top, right, bottom

prev_time = time.time()

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    # Çözünürlüğü yeniden boyutlandır
    frame = resize_frame(frame, target_width, target_height)

    # FPS hesapla
    current_time = time.time()
    fps = int(1 / (current_time - prev_time))
    prev_time = current_time

    # Hedef vuruş alanını çiz
    target_left, target_top, target_right, target_bottom = draw_target_area(frame)

    # Tam merkeze kırmızı nokta yerleştir
    frame_center = (target_width // 2, target_height // 2)
    cv2.circle(frame, frame_center, 7, (0, 0, 255), -1)

    # YOLO ile tahmin yap
    results = model(frame)

    # İHA'nın tespit edilip edilmediğini belirle
    detected = False
    highest_confidence = 0
    best_box = None

    for result in results:
        boxes = result.boxes
        for box in boxes:
            conf = box.conf[0]  # Güven puanı
            detected = True
            if conf > highest_confidence:
                highest_confidence = conf
                best_box = box

    if detected:
        cv2.putText(frame, "HEDEF TESPIT EDILDI", (10, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
        cv2.putText(frame, f"GUVEN DEGERI: {highest_confidence:.2f}", (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
    else:
        cv2.putText(frame, "HEDEF ARANIYOR", (10, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)

    # En yüksek doğruluk oranına sahip nesneye işlem yap
    if best_box:
        x1, y1, x2, y2 = map(int, best_box.xyxy[0])  # Koordinatlar
        object_center = ((x1 + x2) // 2, (y1 + y2) // 2)
        obj_area = (x2 - x1) * (y2 - y1)
        frame_area = target_width * target_height
        obj_percentage = (obj_area / frame_area) * 100

        if tracking_start_time is None:
            tracking_start_time = time.time()

        tracking_time = time.time() - tracking_start_time

        # Kilitlenme kontrolü
        if target_left <= object_center[0] <= target_right and target_top <= object_center[1] <= target_bottom:
            if lock_start_time is None:
                lock_start_time = time.time()
                countdown = 4
            elif time.time() - lock_start_time >= lock_duration:
                successful_locks += 1
                lock_start_time = None
                tracking_start_time = None
                cv2.putText(frame, ">>> KILITLENME BASARILI <<<", (target_width // 2 - 200, target_top - 20), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
            else:
                countdown = max(0, countdown - (time.time() - lock_start_time))
                cv2.putText(frame, f"{int(countdown)}", ((x1 + x2) // 2, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2)
        else:
            lock_start_time = None
            tracking_start_time = None

        # Çizim ve bilgi yazma
        cv2.line(frame, frame_center, object_center, (255, 0, 0), 2, cv2.LINE_AA)
        cv2.putText(frame, f"HEDEFIN KONUMU: {object_center[0] - frame_center[0]} {object_center[1] - frame_center[1]}", (10, 110), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
        cv2.putText(frame, f"HEDEF BOYUTU: {obj_percentage:.2f}%", (10, 140), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
        cv2.putText(frame, f"TAKIP SURESI: {tracking_time:.2f}", (10, 170), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
        cv2.putText(frame, f"BASARILI KILITLENME: {successful_locks}", (10, 200), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)

    # Sol üst köşeye FPS yazısı
    cv2.putText(frame, f"FPS: {fps}", (10, 230), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)

    # Çerçeveyi göster
    cv2.imshow("Frame", frame)

    # Çıkış için 'q' tuşuna bas
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()