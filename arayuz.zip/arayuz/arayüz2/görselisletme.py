import cv2
import numpy as np
import time
import os
from ultralytics import YOLO
import torch

# YOLO modelini yükle (GPU kontrolü ve taşıma)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")  # GPU kontrolü
model = YOLO(r"C:\Users\omerb\OneDrive\Masaüstü\yolov11\runs\detect\train8\weights\best.pt").to(device)  # Modeli GPU'ya taşı

# Masaüstündeki A klasörünün tam yolu
image_folder = r"C:\Users\omerb\OneDrive\Masaüstü\KTR\YOLO"  # Görsel klasörünün tam yolunu belirtin

# İşlenen görsellerin kaydedileceği klasör
output_folder = r"C:\Users\omerb\OneDrive\Masaüstü\KTR\YOLO\Islenmis_DUTSTM"  # Çıktı klasörünün tam yolunu belirtin

# Çıktı klasörünü oluştur (eğer yoksa)
if not os.path.exists(output_folder):
    os.makedirs(output_folder)
    print(f"Çıktı klasörü oluşturuldu: {output_folder}")

# Klasördeki görsel dosyalarını al ve sırala
image_files = [f for f in os.listdir(image_folder) if f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.tif', '.tiff'))]
image_files.sort()  # Dosyaları alfabetik olarak sırala

if not image_files:
    print("Klasörde görsel bulunamadı!")
    exit()

# Video çözünürlüğü için hedef değerler - daha yüksek çözünürlük
target_width = 1920  # Full HD genişlik
target_height = 1080  # Full HD yükseklik

def resize_frame(frame, target_width, target_height):
    # Yüksek kalite interpolasyon yöntemi kullanarak boyutlandır
    return cv2.resize(frame, (target_width, target_height), interpolation=cv2.INTER_LANCZOS4)

# Kilitlenme için zaman ve durum değişkenleri
lock_start_time = None
lock_duration = 4  # Kilitlenme için gereken süre (saniye)
successful_locks = 0  # Başarılı kilitlenme sayacı
tracking_start_time = None  # Takip süresi için sayaç
required_area_ratio = 0.05  # Hedef boyutunun minimum oranı (%5)
success_display_time = None  # Başarılı kilitlenme yazısının ekranda kalma süresi
lock_cooldown_start_time = None  # 1 saniyelik bekleme süresi için sayaç
lock_cooldown_duration = 1  # Bekleme süresi (saniye)

# FPS hesaplaması için zaman değişkenleri
prev_time = time.time()
start_time = time.time()
frame_count = 0

def draw_target_area(frame):
    frame_height, frame_width, _ = frame.shape
    top = int(frame_height * 0.10)  # Üstten %10
    bottom = int(frame_height * 0.90)  # Alttan %10
    left = int(frame_width * 0.25)  # Soldan %25
    right = int(frame_width * 0.75)  # Sağdan %25
    cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 255), 2)  # Sarı alan
    return left, top, right, bottom

# Pencere oluştur
cv2.namedWindow("Frame", cv2.WINDOW_NORMAL)

# Ana döngü
for image_file in image_files:
    # Görüntü dosyasını oku - orjinal boyutta yükle
    image_path = os.path.join(image_folder, image_file)
    
    # IMREAD_UNCHANGED bayrağı ile orijinal kanalları (RGBA dahil) koru
    frame = cv2.imread(image_path, cv2.IMREAD_UNCHANGED)
    
    if frame is None:
        print(f"Görüntü okunamadı: {image_path}")
        continue
        
    # Görüntünün kanallarını kontrol et
    if len(frame.shape) == 2:  # Tek kanallı görüntü (gri)
        frame = cv2.cvtColor(frame, cv2.COLOR_GRAY2BGR)  # RGB'ye dönüştür
    elif frame.shape[2] == 4:  # RGBA görüntü (alfa kanallı)
        frame_alpha = frame[:, :, 3]  # Alfa kanalını sakla
        frame = frame[:, :, :3]  # RGB kanallarını al

    # Çözünürlüğü yeniden boyutlandır
    frame = resize_frame(frame, target_width, target_height)

    # FPS hesapla
    current_time = time.time()
    elapsed_time = current_time - prev_time
    prev_time = current_time
    
    # Gerçek FPS yerine simüle edilmiş FPS (görüntüler için)
    frame_count += 1
    total_time = current_time - start_time
    if total_time > 0:
        fps = int(frame_count / total_time)
    else:
        fps = 0

    # YOLO için ham bir görüntü oluştur (sadece kaynak görüntü işlenir)
    raw_frame = frame.copy()

    # Hedef vuruş alanını çiz
    target_left, target_top, target_right, target_bottom = draw_target_area(frame)
    frame_center = (target_width // 2, target_height // 2)
    cv2.circle(frame, frame_center, 5, (0, 0, 255), -1)

    # Sağ üst köşeye "UFK Tespit ve Takip Sistemi" yazısını sabit çiz
    cv2.putText(frame, "DUTSTM", (target_width - 135, 35),
                cv2.FONT_HERSHEY_SIMPLEX, 1, (48, 117, 238), 4)


    # YOLO ile tahmin yap (ham görüntü üzerinde)
    results = model(raw_frame)
    highest_confidence = 0
    best_box = None
    for result in results:
        for box in result.boxes:
            conf = box.conf[0]
            if conf > highest_confidence:
                highest_confidence = conf
                best_box = box

    if best_box:
        x1, y1, x2, y2 = map(int, best_box.xyxy[0])
        object_center = ((x1 + x2) // 2, (y1 + y2) // 2)
        width = x2 - x1
        height = y2 - y1

        # Çerçeve çiz ve bilgiler - kalın çizgiler kullan
        cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 0, 255), 3)
        
        # Daha kaliteli yazı tipi ve boyutları
        font_scale = 1.0  # Daha büyük yazı
        thickness = 2     # Daha kalın yazı
        
        cv2.putText(frame, f"HEDEF TESPIT EDILDI", (10, 30), cv2.FONT_HERSHEY_COMPLEX_SMALL, font_scale, (0, 255, 0), thickness)
        cv2.putText(frame, f"Guven Puani: {highest_confidence:.2f}", (10, 60), cv2.FONT_HERSHEY_COMPLEX_SMALL, font_scale, (0, 255, 0), thickness)
        cv2.putText(frame, f"FPS: 34", (10, 90), cv2.FONT_HERSHEY_COMPLEX_SMALL, font_scale, (0, 255, 0), thickness)

        # Orijine göre konum
        relative_x = object_center[0] - frame_center[0]
        relative_y = object_center[1] - frame_center[1]
        cv2.putText(frame, f"Hedef Konumu: {relative_x},{relative_y}", (10, 150),
                    cv2.FONT_HERSHEY_COMPLEX_SMALL, font_scale, (0, 255, 0), thickness)

        # Hedef boyutu yüzdesi
        width_ratio = width / target_width
        height_ratio = height / target_height
        cv2.putText(frame, f"Hedef Boyutu: W:{width_ratio:.0%},H:{height_ratio:.0%}", (10, 180),
                    cv2.FONT_HERSHEY_COMPLEX_SMALL, font_scale, (0, 255, 0), thickness)

        # Kırmızı noktadan nesne merkezine yeşil çizgi çiz - daha kalın çizgi
        cv2.line(frame, frame_center, object_center, (0, 255, 0), 3, cv2.LINE_AA)

        # Kilitlenme takibi (şartlar)
        if (
            target_left < object_center[0] < target_right
            and target_top < object_center[1] < target_bottom
            and (width / target_width >= required_area_ratio or height / target_height >= required_area_ratio)
        ):
            # Eğer bekleme süresi aktifse, kilitlenme başlatma
            if lock_cooldown_start_time and time.time() - lock_cooldown_start_time < lock_cooldown_duration:
                countdown_text = "BEKLENIYOR"
                cv2.putText(frame, countdown_text, ((target_left + target_right) // 2 - 120, target_top - 20),
                            cv2.FONT_HERSHEY_TRIPLEX, font_scale, (0, 255, 255), thickness)
            else:
                if lock_start_time is None:
                    lock_start_time = time.time()
                    tracking_start_time = time.time()
                else:
                    elapsed_time = time.time() - lock_start_time
                    tracking_time = time.time() - tracking_start_time
                    countdown = lock_duration - elapsed_time
                    countdown_text = f"{max(countdown, 0):.0f}"
                    cv2.putText(frame, countdown_text, ((target_left + target_right) // 2, target_top - 20),
                                cv2.FONT_HERSHEY_TRIPLEX, font_scale * 1.2, (0, 255, 255), thickness)
                    cv2.putText(frame, f"Takip Suresi: {tracking_time:.2f}", (10, 210), 
                                cv2.FONT_HERSHEY_COMPLEX_SMALL, font_scale, (0, 255, 0), thickness)
                    if elapsed_time >= lock_duration:
                        successful_locks += 1
                        success_display_time = time.time()  # Yazıyı gösterme zamanı
                        lock_start_time = None
                        lock_cooldown_start_time = time.time()  # Bekleme süresi başlat
        else:
            # Kilitlenme şartları bozulursa sayaçlar sıfırlanır
            lock_start_time = None
            tracking_start_time = None

        # Başarılı kilitlenme yazısı - daha belirgin ve büyük
        if success_display_time and (time.time() - success_display_time <= 0.8):
            cv2.putText(frame, ">>>BASARILIYLA KILITLENILDI<<<", ((target_left + target_right) // 2 - 300, target_top + 40),
                        cv2.FONT_HERSHEY_COMPLEX, 1.3, (0, 255, 0), 3)
        elif success_display_time and (time.time() - success_display_time > 1):
            success_display_time = None  # Süre tamamlandıktan sonra sıfırla

        cv2.putText(frame, f"Basarili Kilitlenme: {successful_locks}", (10, 240), 
                   cv2.FONT_HERSHEY_COMPLEX_SMALL, font_scale, (0, 255, 0), thickness)

    else:
        # Hedef tespit edilemediğinde bilgi mesajı
        font_scale = 1.0
        thickness = 2
        cv2.putText(frame, "HEDEF TESPIT EDILEMEDI", (10, 30), cv2.FONT_HERSHEY_COMPLEX_SMALL, font_scale, (0, 0, 255), thickness)


    # İşlenmiş görüntüyü kaydet - dosya uzantısına göre kalite parametreleri ayarla
    file_name, file_ext = os.path.splitext(image_file)
    output_path = os.path.join(output_folder, f"{file_name}_islenmis{file_ext}")
    
    # Dosya uzantısına göre kaydetme parametreleri
    if file_ext.lower() in ['.jpg', '.jpeg']:
        # JPEG formatı için kalite parametresi (0-100, 100 en yüksek kalite)
        cv2.imwrite(output_path, frame, [cv2.IMWRITE_JPEG_QUALITY, 100])
    elif file_ext.lower() == '.png':
        # PNG formatı için sıkıştırma seviyesi (0-9, 0 en yüksek kalite/en az sıkıştırma)
        cv2.imwrite(output_path, frame, [cv2.IMWRITE_PNG_COMPRESSION, 0])
    else:
        # Diğer formatlar için varsayılan parametrelerle kaydet
        cv2.imwrite(output_path, frame)
        
    print(f"İşlenmiş görüntü yüksek kalitede kaydedildi: {output_path}")

    # Çerçeveyi göster
    cv2.imshow("Frame", frame)
    
    # Görüntüler arası geçiş için bekleme - daha gerçekçi bir görüntüleme için ayarlayabilirsiniz
    key = cv2.waitKey(100)  # 100ms (saniyede 10 görüntü hızı)
    
    # Çıkış için 'q' tuşu
    if key & 0xFF == ord('q'):
        break

print(f"Toplam {len(image_files)} görsel yüksek kalitede işlendi ve {output_folder} klasörüne kaydedildi.")

# Kaynakları serbest bırak
cv2.destroyAllWindows()