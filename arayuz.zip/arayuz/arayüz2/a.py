from pymavlink import mavutil
import time

class ArduPilotControl:
    def __init__(self, port='COM3', baudrate=57600):
        # MAVLink bağlantısını başlat
        self.connection = mavutil.mavlink_connection(port, baud=baudrate)
        print(f"Bağlantı bekleniyor... ({port})")
        self.connection.wait_heartbeat()
        print("Bağlantı kuruldu!")

    def set_mode(self, mode):
        """
        ArduPilot mod değiştirme
        Modlar: STABILIZE, GUIDED, AUTO, RTL, LOITER, etc.
        """
        # Modu büyük harfe çevir
        mode = mode.upper()
        
        # Mod map - ArduPilot modları
        mode_mapping = self.connection.mode_mapping()
        
        if mode not in mode_mapping:
            print(f"Hata: {mode} modu bulunamadı!")
            print(f"Mevcut modlar: {list(mode_mapping.keys())}")
            return False

        mode_id = mode_mapping[mode]
        
        # Mod değiştirme komutu gönder
        self.connection.mav.set_mode_send(
            self.connection.target_system,
            mavutil.mavlink.MAV_MODE_FLAG_CUSTOM_MODE_ENABLED,
            mode_id)
        
        # Mod değişikliğini bekle
        for _ in range(3):
            msg = self.connection.recv_match(type='HEARTBEAT', blocking=True, timeout=1)
            if msg and msg.custom_mode == mode_id:
                print(f"Mod başarıyla değiştirildi: {mode}")
                return True
        
        print("Mod değiştirilemedi!")
        return False

    def set_roll_angle(self, roll_angle):
        """Roll açısını ayarla (derece cinsinden)"""
        try:
            # Roll açısını radyana çevir
            roll_rad = roll_angle * 3.14159 / 180.0
            
            # RC override için değer hesapla (1500 ± 500)
            # 0 derece = 1500
            # -45 derece = 1000
            # +45 derece = 2000
            rc_value = int(1500 + (roll_angle * 500 / 45))
            rc_value = max(1000, min(2000, rc_value))  # Değeri sınırla
            
            # RC override komutunu gönder
            self.connection.mav.rc_channels_override_send(
                self.connection.target_system,
                self.connection.target_component,
                rc_value,  # Roll (kanal 1)
                0,  # Pitch (değiştirilmiyor)
                0,  # Throttle (değiştirilmiyor)
                0,  # Yaw (değiştirilmiyor)
                0, 0, 0, 0)  # Diğer kanallar
            
            print(f"Roll komutu gönderildi: {roll_angle} derece (RC değeri: {rc_value})")
            return True
            
        except Exception as e:
            print(f"Roll ayarlama hatası: {e}")
            return False

    def clear_rc_override(self):
        """RC override'ı temizle"""
        self.connection.mav.rc_channels_override_send(
            self.connection.target_system,
            self.connection.target_component,
            0, 0, 0, 0, 0, 0, 0, 0)  # Tüm kanalları temizle
        print("RC override temizlendi")

    def close(self):
        """Bağlantıyı kapat"""
        self.clear_rc_override()
        self.connection.close()
        print("Bağlantı kapatıldı")

# Örnek kullanım
if __name__ == "__main__":
    try:
        # Kontrol nesnesini oluştur
        drone = ArduPilotControl()
        
        # Önce GUIDED moda geç
        if drone.set_mode("GUIDED"):
            time.sleep(1)  # Mod değişikliği için bekle
            
            # Roll açısını 45 dereceye ayarla
            drone.set_roll_angle(45)
            time.sleep(3)  # Etkiyi gör
            
            # Roll'u sıfırla
            drone.set_roll_angle(0)
            time.sleep(10)

            drone.set_roll_angle(-45)
            time.sleep(10)
            drone.set_roll_angle(30)
            time.sleep(10)
            
            # Override'ı temizle
            drone.clear_rc_override()
            
    except KeyboardInterrupt:
        print("\nProgram kullanıcı tarafından durduruldu")
    except Exception as e:
        print(f"Hata oluştu: {e}")
    finally:
        # Bağlantıyı temiz bir şekilde kapat
        drone.close()