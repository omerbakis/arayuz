import cv2
import numpy as np
import onnxruntime as ort
import time

def sigmoid(x):
    return 1 / (1 + np.exp(-x))

def non_max_suppression(boxes, scores, iou_threshold):
    indices = cv2.dnn.NMSBoxes(boxes, scores, score_threshold=0.5, nms_threshold=iou_threshold)
    return indices.flatten() if len(indices) > 0 else []

# Yollar
model_path = r"C:\Users\omerb\OneDrive\Masaüstü\yolov11\runs\detect\train8\weights\best.onnx"
video_path = r"C:\Users\omerb\OneDrive\Masaüstü\yolov11\datasets\test\uav1.mp4"

# CUDA destekli ONNX oturumu oluştur
session = ort.InferenceSession(
    model_path,
    providers=["CUDAExecutionProvider", "CPUExecutionProvider"]
)

input_name = session.get_inputs()[0].name
img_size = session.get_inputs()[0].shape[2]

cap = cv2.VideoCapture(video_path)

# FPS ölçümü başlat
frame_count = 0
start_time = time.time()

while True:
    ret, frame = cap.read()
    if not ret:
        break

    orig_h, orig_w = frame.shape[:2]

    # Görüntüyü ön işlemeye al
    img = cv2.resize(frame, (img_size, img_size))
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0
    img = np.transpose(img, (2, 0, 1))
    img = np.expand_dims(img, axis=0)

    # Model tahmini
    outputs = session.run(None, {input_name: img})[0]
    outputs = np.squeeze(outputs)  # (5, 8400)

    obj = sigmoid(outputs[0])
    cx = outputs[1] * orig_w / img_size
    cy = outputs[2] * orig_h / img_size
    w  = outputs[3] * orig_w / img_size
    h  = outputs[4] * orig_h / img_size

    x1 = cx - w / 2
    y1 = cy - h / 2

    boxes, scores = [], []
    for i in range(len(obj)):
        if obj[i] > 0.5 and w[i] > 10 and h[i] > 10:
            boxes.append([int(x1[i]), int(y1[i]), int(w[i]), int(h[i])])
            scores.append(float(obj[i]))

    indices = non_max_suppression(boxes, scores, iou_threshold=0.5)

    for i in indices:
        x, y, w, h = boxes[i]
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
        cv2.putText(frame, f"{scores[i]:.2f}", (x, y - 10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)

    # FPS hesapla ve yazdır
    frame_count += 1
    if frame_count % 30 == 0:
        fps = frame_count / (time.time() - start_time)
        print(f"📈 Ortalama FPS: {fps:.2f}")

    cv2.imshow("YOLOv11 ONNX + CUDA", frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
