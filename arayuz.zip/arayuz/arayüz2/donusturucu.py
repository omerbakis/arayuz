from ultralytics import YOLO
import os

# PT model yolu
pt_model_path = r"C:\Users\omerb\OneDrive\Masaüstü\yolov11\runs\detect\train8\weights\best.pt"

# PT dosyasının varlığını kontrol et
if not os.path.exists(pt_model_path):
    print(f"HATA: PT dosyası bulunamadı: {pt_model_path}")
    exit()

print("PT dosyası bulundu. ONNX dosyası oluşturuluyor...")

try:
    # PT modelini yükle
    model = YOLO(pt_model_path)
    
    # ONNX formatına export et (farklı opset versiyonları ile)
    print("ONNX export işlemi başlatılıyor...")
    
    # Önce opset 11 ile dene (daha uyumlu)
    try:
        success = model.export(format="onnx", imgsz=640, opset=11)
        print(f"ONNX dosyası başarıyla oluşturuldu (opset 11): {success}")
    except Exception as e:
        print(f"Opset 11 ile hata: {e}")
        
        # Opset 12 ile dene
        try:
            success = model.export(format="onnx", imgsz=640, opset=12)
            print(f"ONNX dosyası başarıyla oluşturuldu (opset 12): {success}")
        except Exception as e2:
            print(f"Opset 12 ile hata: {e2}")
            
            # Varsayılan ayarlarla dene
            try:
                success = model.export(format="onnx", imgsz=640)
                print(f"ONNX dosyası başarıyla oluşturuldu (varsayılan): {success}")
            except Exception as e3:
                print(f"Varsayılan ayarlarla hata: {e3}")
                raise e3

except Exception as e:
    print(f"ONNX dosyası oluşturulurken genel hata: {e}")
    print("Alternatif olarak TensorRT veya TorchScript formatını kullanabilirsiniz.")
    
    # TorchScript alternatifi
    try:
        print("TorchScript formatında export deneniyor...")
        model = YOLO(pt_model_path)
        success = model.export(format="torchscript", imgsz=640)
        print(f"TorchScript dosyası oluşturuldu: {success}")
    except Exception as ts_error:
        print(f"TorchScript export hatası: {ts_error}")

print("İşlem tamamlandı.")