import numpy as np

class TargetSelector:
    def __init__(self, weights=[3, 1, 2, 2, 1], k=20, x0=0.5):
        self.weights = weights
        self.k = k
        self.x0 = x0
        self.track_history = {}  # {target_hash: [positions]}
        self.last_locked_ids = []  # Son kilitlenen hedef ID'lerini saklayacak liste
        self.active_target_id = None  # Şu anda takip edilen hedef ID'si
        self.target_persistence = {}  # Hedeflerin gerçek ID'lerini takip etmek için
        self.next_target_id = 1  # Benzersiz hedef ID'leri için sayaç
        self.active_tracking_start = None  # Aktif takibin başlangıç zamanı
        self.min_tracking_duration = 1.0  # Minimum hedef takip süresi (saniye)
        
    def calculate_score(self, box, frame_center, current_time=None):
        x1, y1, x2, y2, conf = box
        box_center = ((x1+x2)//2, (y1+y2)//2)
        
        # Gerçek target_id'yi bul veya yeni bir tane oluştur
        target_id = self._match_or_create_target(box, box_center)
            
        # Konum geçmişini güncelle
        if target_id not in self.track_history:
            self.track_history[target_id] = []
        self.track_history[target_id].append(box_center)
        if len(self.track_history[target_id]) > 5:
            self.track_history[target_id].pop(0)
            
        # Parametreler hesaplanması
        C_dist = np.sqrt((box_center[0]-frame_center[0])**2 + 
                        (box_center[1]-frame_center[1])**2)
        inv_C_dist = 1/(C_dist + 1e-6)
        
        S_size = (x2-x1) * (y2-y1)
        
        V_motion = 0.0
        if len(self.track_history[target_id]) >= 2:
            dx = self.track_history[target_id][-1][0] - self.track_history[target_id][-2][0]
            dy = self.track_history[target_id][-1][1] - self.track_history[target_id][-2][1]
            V_motion = np.sqrt(dx**2 + dy**2)/0.033  # 30 FPS varsayımı
            
        A_change = 0.0
        if len(self.track_history[target_id]) >= 3:
            V_prev = np.sqrt((self.track_history[target_id][-2][0]-self.track_history[target_id][-3][0])**2 + 
                            (self.track_history[target_id][-2][1]-self.track_history[target_id][-3][1])**2)/0.033
            A_change = abs(V_motion - V_prev)/0.033
            
        P_stability = 1 - 1/(1 + np.exp(-self.k*(A_change - self.x0)))
        sigmoid_conf = 1/(1 + np.exp(-self.k*(conf - self.x0)))
        
        # Ağırlıklı temel skor
        base_score = (
            self.weights[0] * inv_C_dist +
            self.weights[1] * S_size +
            self.weights[2] * (1/(V_motion + 1e-6)) +
            self.weights[3] * P_stability +
            self.weights[4] * sigmoid_conf
        )
        
        # Skor ayarlamaları
        final_score = base_score
        
        # Hedef kilitlenme kuralları uygula
        if target_id in self.last_locked_ids:
            # Eğer bu hedefe daha önce kilitlenildiyse ve tekrar kilitlenmeye çalışılıyorsa skorunu düşür
            # ancak başka bir hedefe kilitlenildiyse (last_locked_ids içinde en az 2 farklı ID varsa) bu kuralı göz ardı et
            if len(self.last_locked_ids) == 1 or self.last_locked_ids[-2] == target_id:
                final_score *= 0.3  # Skoru önemli ölçüde düşür
        
        # Aktif hedef varsa ve yeterli süre takip edilmişse, o hedefi tercih et
        if self.active_target_id == target_id and current_time and self.active_tracking_start:
            if current_time - self.active_tracking_start < self.min_tracking_duration:
                # Aktif hedefi tercih et (henüz minimum süre tamamlanmadı)
                final_score *= 1.5  # Aktif hedefin skorunu artır
        
        return final_score, target_id
    
    def _match_or_create_target(self, current_box, current_center):
        """Mevcut kutuyu önceki hedeflerle eşleştirmeye çalışır veya yeni hedef oluşturur"""
        x1, y1, x2, y2, _ = current_box
        box_width, box_height = x2-x1, y2-y1
        min_iou_threshold = 0.4
        best_match_id = None
        best_match_iou = 0
        
        # Hedefleri konum ve boyut benzerliğine göre eşleştir
        for target_id, boxes in self.target_persistence.items():
            if not boxes:
                continue
                
            prev_box = boxes[-1]
            prev_x1, prev_y1, prev_x2, prev_y2 = prev_box[:4]
            
            # IoU hesapla
            x_left = max(x1, prev_x1)
            y_top = max(y1, prev_y1)
            x_right = min(x2, prev_x2)
            y_bottom = min(y2, prev_y2)
            
            if x_right < x_left or y_bottom < y_top:
                continue  # Kesişme yok
                
            intersection = (x_right - x_left) * (y_bottom - y_top)
            area1 = box_width * box_height
            area2 = (prev_x2 - prev_x1) * (prev_y2 - prev_y1)
            union = area1 + area2 - intersection
            iou = intersection / union if union > 0 else 0
            
            if iou > min_iou_threshold and iou > best_match_iou:
                best_match_id = target_id
                best_match_iou = iou
        
        if best_match_id is not None:
            # Mevcut hedefle eşleşti
            self.target_persistence[best_match_id].append(current_box)
            if len(self.target_persistence[best_match_id]) > 30:  # Son 30 frame'i tut
                self.target_persistence[best_match_id].pop(0)
            return best_match_id
        else:
            # Yeni hedef oluştur
            new_id = self.next_target_id
            self.next_target_id += 1
            self.target_persistence[new_id] = [current_box]
            return new_id
    
    def set_locked_target(self, target_id, current_time=None):
        """Bir hedefe kilitlendiğinde çağrılan fonksiyon"""
        if target_id not in self.last_locked_ids:
            self.last_locked_ids.append(target_id)
            # Listeyi sınırlı tut (son 3 kilitlenen hedefi hatırla)
            if len(self.last_locked_ids) > 3:
                self.last_locked_ids.pop(0)
    
    def set_active_target(self, target_id, current_time=None):
        """Aktif hedefi ayarla ve takip süresini başlat"""
        if self.active_target_id != target_id:
            self.active_target_id = target_id
            self.active_tracking_start = current_time
    
    def can_lock_target(self, target_id):
        """Belirli bir hedefe kilitlenmenin kurallara uygun olup olmadığını kontrol eder"""
        # Eğer son kilitlenilen hedef bu hedefse ve başka bir hedefe kilitlenilmediyse, kilitlenme izni verme
        if self.last_locked_ids and self.last_locked_ids[-1] == target_id:
            # Eğer son 2 kilitlenme farklı hedeflerdeyse, tekrar kilitlenmeye izin ver
            if len(self.last_locked_ids) >= 2 and self.last_locked_ids[-2] != target_id:
                return True
            return False
        return True  # Bu hedefe daha önce kilitlenilmemişse veya araya başka hedef girmişse
    
    def clean_old_targets(self, max_age=30):
        """Uzun süredir görünmeyen hedefleri temizle"""
        current_targets = set(self.target_persistence.keys())
        for target_id in list(self.track_history.keys()):
            if target_id not in current_targets:
                del self.track_history[target_id]
                
        # Aynı zamanda aktif hedef yoksa active_tracking_start'ı sıfırla
        if self.active_target_id not in current_targets:
            self.active_target_id = None
            self.active_tracking_start = None