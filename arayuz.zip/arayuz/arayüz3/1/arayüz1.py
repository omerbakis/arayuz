import cv2
import numpy as np
import time
from ultralytics import YOLO
import torch
import json
from DUTSTM1 import TargetSelector  # Özel hedef seçim modülü

# YOLO modelini yükle
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = YOLO(r"C:\Users\omerb\OneDrive\Masaüstü\yolov11\runs\detect\train9\weights\best.pt").to(device)

# Video kaynağını aç
video_path = r"C:\Users\omerb\OneDrive\Masaüstü\yolov11\datasets\test\suf.mp4"
cap = cv2.VideoCapture(video_path)

# Çözünürlük ayarları
target_width, target_height = 1280, 720

def resize_frame(frame):
    return cv2.resize(frame, (target_width, target_height), interpolation=cv2.INTER_LINEAR)

# Hedef takip sistemi başlat
target_selector = TargetSelector(weights=[3, 1, 2, 2, 1])  # DUTSTM parametreleri

# Kilitlenme parametreleri
lock_duration = 4
required_area_ratio = 0.05
lock_start_time = None
tracking_start_time = None
successful_locks = 0
success_display_start = None
current_target_id = None

# Soğuma süresi değişkenleri
lock_cooldown_start_time = None
lock_cooldown_duration = 1

# FPS hesaplama
prev_time = time.time()

def draw_target_area(frame):
    """Hedef vuruş alanını çizer"""
    top = int(target_height * 0.10)
    bottom = int(target_height * 0.90)
    left = int(target_width * 0.25)
    right = int(target_width * 0.75)
    cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 255), 2)
    return left, top, right, bottom

def check_lock_conditions(box, target_area):
    """Şartnameye uygun kilitlenme koşullarını kontrol eder"""
    x1, y1, x2, y2, _ = box
    object_center = ((x1 + x2) // 2, (y1 + y2) // 2)
    width = x2 - x1
    height = y2 - y1
    
    # Boyut kontrolü
    size_ok = (width/target_width >= required_area_ratio) or \
              (height/target_height >= required_area_ratio)
    
    # Alan kontrolü
    area_ok = (object_center[0] > target_area[0]) and (object_center[0] < target_area[2]) and \
              (object_center[1] > target_area[1]) and (object_center[1] < target_area[3])
    
    return size_ok and area_ok

# Ana işlem döngüsü
while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    # Görüntü işleme
    frame = resize_frame(frame)
    raw_frame = frame.copy()
    
    # Hedef vuruş alanını çiz
    target_left, target_top, target_right, target_bottom = draw_target_area(frame)
    frame_center = (target_width//2, target_height//2)
    cv2.circle(frame, frame_center, 5, (0, 0, 255), -1)  # Merkez noktası
    
    # Sağ üst köşeye "UFK Tespit ve Takip Sistemi" yazısını çiz
    cv2.putText(frame, "UFK", (target_width - 140, 55),
                cv2.FONT_HERSHEY_SIMPLEX, 2, (48, 117, 238), 8)
    cv2.putText(frame, "Tespit ve Takip", (target_width - 137, 78),
                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (48, 117, 238), 2)
    cv2.putText(frame, "Sistemi", (target_width - 135, 110),
                cv2.FONT_HERSHEY_SIMPLEX, 1, (48, 117, 238), 4)
    
    # FPS hesapla
    current_time = time.time()
    fps = int(1 / (current_time - prev_time))
    prev_time = current_time

    # YOLO ile nesne tespiti
    results = model(raw_frame)
    current_boxes = []
    
    # Tüm tespit edilen nesneleri topla
    for result in results:
        for box in result.boxes:
            x1, y1, x2, y2 = map(int, box.xyxy[0])
            conf = box.conf[0].item()
            current_boxes.append((x1, y1, x2, y2, conf))
    
    # Eski hedefleri temizle
    target_selector.clean_old_targets()
    
    # DUTSTM ile en iyi hedefi seç
    best_box = None
    best_score = -np.inf
    best_target_id = None
    
    # Önce mevcut hedefe devam etmek mümkün mü kontrol et
    if current_target_id is not None and lock_start_time is not None:
        for box in current_boxes:
            score, target_id = target_selector.calculate_score(box, frame_center, current_time)
            if target_id == current_target_id:
                best_box = box
                best_target_id = target_id
                target_selector.set_active_target(target_id, current_time)
                break
    
    # Eğer mevcut hedef bulunamadıysa, en iyi hedefi seç
    if best_box is None:
        for box in current_boxes:
            score, target_id = target_selector.calculate_score(box, frame_center, current_time)
            if score > best_score:
                best_score = score
                best_box = box
                best_target_id = target_id
    
    # Kilitlenme mantığı
    if best_box:
        x1, y1, x2, y2, conf = best_box
        width = x2 - x1
        height = y2 - y1
        object_center = ((x1 + x2) // 2, (y1 + y2) // 2)
        
        # Hedefi aktif olarak işaretle
        target_selector.set_active_target(best_target_id, current_time)
        current_target_id = best_target_id
        
        # Görselleştirme (ikinci kod tasarımına göre)
        cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 0, 255), 3)
        cv2.putText(frame, f"HEDEF TESPIT EDILDI (ID: {best_target_id})", (10, 30), 
                    cv2.FONT_HERSHEY_COMPLEX_SMALL, 0.8, (0, 255, 0), 1)
        cv2.putText(frame, f"Guven Puani: {conf:.2f}", (10, 50), 
                    cv2.FONT_HERSHEY_COMPLEX_SMALL, 0.8, (0, 255, 0), 1)
        cv2.putText(frame, f"FPS: {fps}", (10, 70), 
                    cv2.FONT_HERSHEY_COMPLEX_SMALL, 0.8, (0, 255, 0), 1)
        
        # Orijine göre konum
        relative_x = object_center[0] - frame_center[0]
        relative_y = object_center[1] - frame_center[1]
        cv2.putText(frame, f"Hedef Konumu: {relative_x},{relative_y}", (10, 110),
                    cv2.FONT_HERSHEY_COMPLEX_SMALL, 0.8, (0, 255, 0), 1)
        
        # Hedef boyutu yüzdesi
        width_ratio = width / target_width
        height_ratio = height / target_height
        cv2.putText(frame, f"Hedef Boyutu: W:{width_ratio:.0%},H:{height_ratio:.0%}", (10, 130),
                    cv2.FONT_HERSHEY_COMPLEX_SMALL, 0.8, (0, 255, 0), 1)
        
        # Kırmızı noktadan nesne merkezine yeşil çizgi çiz
        cv2.line(frame, frame_center, object_center, (0, 255, 0), 2, cv2.LINE_AA)
        
        # Kilitlenme koşulları kontrol
        if check_lock_conditions(best_box, (target_left, target_top, target_right, target_bottom)):
            # Kilitlenme kuralları kontrolü
            can_lock = target_selector.can_lock_target(best_target_id)
            
            # Eğer bekleme süresi aktifse veya bu hedefe kilitlenme izni yoksa, kilitlenme başlatma
            if (lock_cooldown_start_time and time.time() - lock_cooldown_start_time < lock_cooldown_duration) or not can_lock:
                countdown_text = "BEKLENIYOR"
                if not can_lock:
                    countdown_text = "HEDEF KILITLENDI - BASKA HEDEF SEC"
                cv2.putText(frame, countdown_text, ((target_left + target_right) // 2 - 170, target_top - 10),
                            cv2.FONT_HERSHEY_TRIPLEX, 0.8, (0, 255, 255), 1)
            else:
                if lock_start_time is None:
                    lock_start_time = time.time()
                    tracking_start_time = time.time()
                else:
                    elapsed_time = time.time() - lock_start_time
                    tracking_time = time.time() - tracking_start_time
                    countdown = lock_duration - elapsed_time
                    countdown_text = f"{max(countdown, 0):.0f}"
                    
                    cv2.putText(frame, countdown_text, ((target_left + target_right) // 2, target_top - 10),
                                cv2.FONT_HERSHEY_TRIPLEX, 0.8, (0, 255, 255), 1)
                    cv2.putText(frame, f"Takip Suresi: {tracking_time:.2f}", (10, 170), 
                                cv2.FONT_HERSHEY_COMPLEX_SMALL, 0.8, (0, 255, 0), 1)
                    
                    if elapsed_time >= lock_duration:
                        # Sunucuya veri gönderim simülasyonu
                        lock_data = {
                            "timestamp": time.time(),
                            "target_id": str(best_target_id),
                            "bounding_box": [x1, y1, x2, y2],
                            "confidence": conf,
                            "duration": elapsed_time
                        }
                        print(">>> KILITLENME VERISI <<<")
                        print(json.dumps(lock_data, indent=2))
                        
                        # Kilitlenme kaydı
                        target_selector.set_locked_target(best_target_id, current_time)
                        
                        successful_locks += 1
                        success_display_start = time.time()
                        lock_start_time = None
                        lock_cooldown_start_time = time.time()  # Bekleme süresi başlat
        else:
            # Kilitlenme şartları bozulursa sayaçlar sıfırlanır
            lock_start_time = None
            tracking_start_time = None
    
    # Son kilitlenilen hedefler listesini göster
    locked_ids_text = "Son Kilitlenilen Hedefler: " + ", ".join([str(tid) for tid in target_selector.last_locked_ids[-3:]])
    cv2.putText(frame, locked_ids_text, (10, target_height - 30), 
                cv2.FONT_HERSHEY_COMPLEX_SMALL, 0.8, (0, 255, 0), 1)
    
    # Başarılı kilitlenme bildirimi (yeni tasarıma göre)
    if success_display_start and (time.time() - success_display_start <= 0.8):
        cv2.putText(frame, ">>>BASARILIYLA KILITLENILDI<<<", 
                    ((target_left + target_right) // 2 - 245, target_top + 25),
                    cv2.FONT_HERSHEY_COMPLEX_SMALL, 1.2, (0, 255, 0), 1)
    elif success_display_start and (time.time() - success_display_start > 1):
        success_display_start = None  # Süre tamamlandıktan sonra sıfırla
    
    cv2.putText(frame, f"Basarili Kilitlenme: {successful_locks}", (10, 190), 
                cv2.FONT_HERSHEY_COMPLEX_SMALL, 0.8, (0, 255, 0), 1)
    
    # Görüntüyü göster
    cv2.imshow("UFK - Otonom Hedef Takip Sistemi", frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Temizlik
cap.release()
cv2.destroyAllWindows()