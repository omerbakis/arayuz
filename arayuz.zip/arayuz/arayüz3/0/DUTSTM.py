import numpy as np

class TargetSelector:
    def __init__(self, weights=[3, 1, 2, 2, 1], k=20, x0=0.5):
        self.weights = weights
        self.k = k
        self.x0 = x0
        self.track_history = {}  # {target_hash: [positions]}x"
        
    def calculate_score(self, box, frame_center):
        x1, y1, x2, y2, conf = box
        target_hash = hash((x1, y1, x2, y2))
        current_center = ((x1+x2)//2, (y1+y2)//2)
        
        # Konum geçmişini güncelle
        if target_hash not in self.track_history:
            self.track_history[target_hash] = []
        self.track_history[target_hash].append(current_center)
        if len(self.track_history[target_hash]) > 5:
            self.track_history[target_hash].pop(0)
            
        # Parametreler
        C_dist = np.sqrt((current_center[0]-frame_center[0])**2 + 
                        (current_center[1]-frame_center[1])**2)
        inv_C_dist = 1/(C_dist + 1e-6)
        
        S_size = (x2-x1) * (y2-y1)
        
        V_motion = 0.0
        if len(self.track_history[target_hash]) >= 2:
            dx = self.track_history[target_hash][-1][0] - self.track_history[target_hash][-2][0]
            dy = self.track_history[target_hash][-1][1] - self.track_history[target_hash][-2][1]
            V_motion = np.sqrt(dx**2 + dy**2)/0.033  # 30 FPS varsayımı
            
        A_change = 0.0
        if len(self.track_history[target_hash]) >= 3:
            V_prev = np.sqrt((self.track_history[target_hash][-2][0]-self.track_history[target_hash][-3][0])**2 + 
                            (self.track_history[target_hash][-2][1]-self.track_history[target_hash][-3][1])**2)/0.033
            A_change = abs(V_motion - V_prev)/0.033
            
        P_stability = 1 - 1/(1 + np.exp(-self.k*(A_change - self.x0)))
        sigmoid_conf = 1/(1 + np.exp(-self.k*(conf - self.x0)))
        
        # Ağırlıklı skor
        score = (
            self.weights[0] * inv_C_dist +
            self.weights[1] * S_size +
            self.weights[2] * (1/(V_motion + 1e-6)) +
            self.weights[3] * P_stability +
            self.weights[4] * sigmoid_conf
        )
        return score, target_hash