import cv2
import numpy as np
import time
from ultralytics import YOLO
import torch
import math

# YOLO modelini yükle (GPU kontrolü ve taşıma)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = YOLO(r"C:\Users\omerb\OneDrive\Masaüstü\yolov11\runs\detect\train7\weights\best.pt").to(device)

# Video kaynağını aç
video_path = r"C:\Users\omerb\OneDrive\Masaüstü\yolov11\datasets\test\uav1.mp4"
cap = cv2.VideoCapture(video_path)

# Video çözünürlüğünü ayarla
target_width = 1280
target_height = 720

# Kilitlenme parametreleri
lock_start_time = None
lock_duration = 4  # Kilitlenme için gereken süre (saniye)
successful_locks = 0
tracking_start_time = None
required_area_ratio = 0.05
success_display_time = None
lock_cooldown_start_time = None
lock_cooldown_duration = 1

# Hedef takibi için değişkenler
tracking_target_id = None  # Takip edilen hedef ID'si
locked_targets = set()  # Kilitlenilen hedeflerin ID'lerini tutacak set
previous_positions = {}  # Hedeflerin önceki pozisyonlarını takip etmek için
previous_time = time.time()  # Hız hesaplaması için zaman
focus_area = None  # Odaklanılacak alan

# DUTSTM ağırlıkları - bunları ihtiyaca göre ayarlayabilirsiniz
dutstm_weights = {
    'w1': 0.25,  # Merkeze uzaklık ağırlığı
    'w2': 0.20,  # Boyut optimumu ağırlığı
    'w3': 0.15,  # Hareket vektörü ağırlığı
    'w4': 0.15,  # Stabilite ağırlığı
    'w5': 0.25   # Güven skoru ağırlığı
}

def resize_frame(frame, target_width, target_height):
    return cv2.resize(frame, (target_width, target_height), interpolation=cv2.INTER_LINEAR)

def draw_target_area(frame):
    frame_height, frame_width, _ = frame.shape
    top = int(frame_height * 0.10)
    bottom = int(frame_height * 0.90)
    left = int(frame_width * 0.25)
    right = int(frame_width * 0.75)
    cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 255), 2)
    return left, top, right, bottom

def calculate_distance(x1, y1, x2, y2):
    """İki nokta arasındaki Öklid mesafesini hesaplar"""
    return math.sqrt((x2 - x1)**2 + (y2 - y1)**2)

def calculate_size_score(width, height, frame_width, frame_height):
    """Hedef boyutunun optimum olup olmadığını değerlendirir"""
    size_percentage = (width * height) / (frame_width * frame_height)
    
    # %5'ten küçük hedefler için 0 değeri döndür
    if size_percentage < 0.05:
        return 0
    
    # Optimum boyut için Gaussian dağılım (mu=0.15, sigma=0.1 gibi değerler kullanabilirsiniz)
    mu = 0.15  # Optimal boyut (frame'in %15'i)
    sigma = 0.1  # Tolerans
    
    return math.exp(-((size_percentage - mu)**2) / (2 * sigma**2))

def calculate_motion_vector(current_pos, previous_pos, delta_t):
    """Hareket vektörünün büyüklüğünü hesaplar"""
    if previous_pos is None:
        return 0
    
    distance = calculate_distance(
        current_pos[0], current_pos[1],
        previous_pos[0], previous_pos[1]
    )
    
    return distance / delta_t

def calculate_stability(current_velocity, previous_velocity, delta_t):
    """Hedefin hareket stabilitesini hesaplar"""
    if previous_velocity is None:
        return 1.0  # Varsayılan olarak stabil kabul et
    
    # Hız değişimi
    acceleration = abs(current_velocity - previous_velocity) / delta_t
    
    # Sigmoid fonksiyonu ile 0-1 arasında normalize et
    # A_change değerini 0.50 eşik değeri ile karşılaştır
    return 1 - (1 / (1 + math.exp(-20 * (acceleration - 0.50))))

def sigmoid_confidence(conf):
    """Güven skorunu sigmoid fonksiyonu ile 0-1 arasına dönüştürür"""
    return 1 / (1 + math.exp(-20 * (conf - 0.60)))

def calculate_dutstm_score(target_info, frame_center, delta_t):
    """DUTSTM algoritması ile hedef takip skorunu hesaplar"""
    x, y = target_info['center']
    width, height = target_info['size']
    conf = target_info['confidence']
    
    # Merkeze olan uzaklık (C_dist)
    distance = calculate_distance(x, y, frame_center[0], frame_center[1])
    if distance == 0:  # Sıfıra bölünmeyi engelle
        distance = 0.001
    
    # Boyut skoru (S_size)
    size_score = calculate_size_score(width, height, target_width, target_height)
    
    # Hareket vektörü (V_motion)
    if target_info['id'] in previous_positions:
        prev_pos, prev_time, prev_velocity = previous_positions[target_info['id']]
        current_velocity = calculate_motion_vector((x, y), prev_pos, delta_t)
        
        # Stabilite (P_stability)
        stability = calculate_stability(current_velocity, prev_velocity, delta_t)
    else:
        current_velocity = 0
        stability = 1.0  # Varsayılan olarak stabil kabul et
    
    # Eğer hız çok yüksekse (görüş alanından çıkma riski varsa) skoru düşür
    motion_factor = 1 / (current_velocity + 0.001)  # Sıfıra bölünmeyi engelle
    
    # Güven skoru (sigmoid(C_conf))
    conf_score = sigmoid_confidence(conf)
    
    # Toplam skor hesaplama
    total_score = (
        dutstm_weights['w1'] * (1 / distance) +
        dutstm_weights['w2'] * size_score +
        dutstm_weights['w3'] * motion_factor +
        dutstm_weights['w4'] * stability +
        dutstm_weights['w5'] * conf_score
    )
    
    # Önceki konum ve hız bilgilerini güncelle
    previous_positions[target_info['id']] = ((x, y), time.time(), current_velocity)
    
    return total_score

# FPS hesaplaması için değişken
prev_time = time.time()

# Ana döngü
while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break
    
    current_time = time.time()
    delta_t = current_time - prev_time
    prev_time = current_time
    
    # Çözünürlüğü yeniden boyutlandır
    frame = resize_frame(frame, target_width, target_height)
    
    # FPS hesapla
    fps = int(1 / (delta_t))
    
    # YOLO için ham bir görüntü oluştur
    raw_frame = frame.copy()
    
    # Hedef vuruş alanını çiz
    target_left, target_top, target_right, target_bottom = draw_target_area(frame)
    frame_center = (target_width // 2, target_height // 2)
    cv2.circle(frame, frame_center, 5, (0, 0, 255), -1)
    
    # Arayüzde sabit metinleri ekle
    cv2.putText(frame, "UFK", (target_width - 140, 55),
                cv2.FONT_HERSHEY_SIMPLEX, 2, (48, 117, 238), 8)
    cv2.putText(frame, "Tespit ve Takip", (target_width - 137, 78),
                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (48, 117, 238), 2)
    cv2.putText(frame, "Sistemi", (target_width - 135, 110),
                cv2.FONT_HERSHEY_SIMPLEX, 1, (48, 117, 238), 4)
    
    # Hedef bilgilerini toplamak için boş liste
    targets = []
    target_id = 0
    
    # Odaklanma alanı varsa sadece o alanda, yoksa tüm framede YOLO çalıştır
    if focus_area and tracking_target_id is not None:
        # Odaklanma alanını kırp
        x1, y1, x2, y2 = focus_area
        # Alanın frame dışına taşmamasını sağla
        x1 = max(0, int(x1))
        y1 = max(0, int(y1))
        x2 = min(target_width, int(x2))
        y2 = min(target_height, int(y2))
        
        # Boyutları kontrol et
        if x2 > x1 and y2 > y1:
            cropped_frame = raw_frame[y1:y2, x1:x2]
            
            # Kırpılmış alanda YOLO çalıştır
            results = model(cropped_frame)
            
            # Kutu bilgilerini orijinal koordinatlara dönüştür
            for result in results:
                for box in result.boxes:
                    # Tensor'ı numpy arraye çevir
                    xyxy = box.xyxy[0].cpu().numpy()
                    
                    # Orijinal koordinatlara dönüştür
                    orig_x1 = xyxy[0] + x1
                    orig_y1 = xyxy[1] + y1
                    orig_x2 = xyxy[2] + x1
                    orig_y2 = xyxy[3] + y1
                    
                    # Hedef bilgilerini ekle
                    target_center = ((int(orig_x1) + int(orig_x2)) // 2, (int(orig_y1) + int(orig_y2)) // 2)
                    width = int(orig_x2) - int(orig_x1)
                    height = int(orig_y2) - int(orig_y1)
                    conf = float(box.conf[0])
                    
                    targets.append({
                        'id': target_id,
                        'bbox': (int(orig_x1), int(orig_y1), int(orig_x2), int(orig_y2)),
                        'center': target_center,
                        'size': (width, height),
                        'confidence': conf
                    })
                    target_id += 1
        else:
            # Geçersiz kırpma alanı, tüm çerçeveyi kullan
            results = model(raw_frame)
            for result in results:
                for box in result.boxes:
                    x1, y1, x2, y2 = map(int, box.xyxy[0].cpu().numpy())
                    center = ((x1 + x2) // 2, (y1 + y2) // 2)
                    width = x2 - x1
                    height = y2 - y1
                    conf = float(box.conf[0])
                    
                    targets.append({
                        'id': target_id,
                        'bbox': (x1, y1, x2, y2),
                        'center': center,
                        'size': (width, height),
                        'confidence': conf
                    })
                    target_id += 1
    else:
        # Odaklanma alanı yoksa tüm frame'i kullan
        results = model(raw_frame)
        for result in results:
            for box in result.boxes:
                x1, y1, x2, y2 = map(int, box.xyxy[0].cpu().numpy())
                center = ((x1 + x2) // 2, (y1 + y2) // 2)
                width = x2 - x1
                height = y2 - y1
                conf = float(box.conf[0])
                
                targets.append({
                    'id': target_id,
                    'bbox': (x1, y1, x2, y2),
                    'center': center,
                    'size': (width, height),
                    'confidence': conf
                })
                target_id += 1
    
    # Eğer aktif bir takip yoksa ve hedefler varsa, DUTSTM ile en iyi hedefi seç
    best_target = None
    best_score = -1
    
    if tracking_target_id is None and targets:
        for target in targets:
            # Daha önce kilitlenilmiş bir hedefse atla
            target_center = target['center']
            already_locked = False
            
            for locked_center in locked_targets:
                locked_x, locked_y = locked_center
                dist = calculate_distance(target_center[0], target_center[1], locked_x, locked_y)
                # Eğer merkez konumlar yakınsa, önceden kilitlenmiş kabul et (100px tolerans)
                if dist < 100:
                    already_locked = True
                    break
            
            if already_locked:
                continue
                
            # DUTSTM skoru hesapla
            dutstm_score = calculate_dutstm_score(target, frame_center, delta_t)
            
            if dutstm_score > best_score:
                best_score = dutstm_score
                best_target = target
    elif tracking_target_id is not None and targets:
        # Zaten takip edilen bir hedef varsa, onu bulmaya çalış
        for target in targets:
            if tracking_target_id in previous_positions:
                prev_pos = previous_positions[tracking_target_id][0]
                current_pos = target['center']
                
                # Eğer önceki konuma en yakın hedefse, takibi sürdür
                if not best_target or calculate_distance(
                    current_pos[0], current_pos[1],
                    prev_pos[0], prev_pos[1]) < calculate_distance(
                        best_target['center'][0], best_target['center'][1],
                        prev_pos[0], prev_pos[1]):
                    best_target = target
                    best_score = calculate_dutstm_score(target, frame_center, delta_t)
    
    # Eğer bir hedef seçildiyse, işle
    if best_target:
        x1, y1, x2, y2 = best_target['bbox']
        object_center = best_target['center']
        width, height = best_target['size']
        conf = best_target['confidence']
        
        # Hedef ID'sini takip için güncelle
        tracking_target_id = best_target['id']
        
        # Odaklanma alanını güncelle (hedefin 2 katı genişliğinde)
        center_x, center_y = object_center
        focus_width = width * 2
        focus_height = height * 2
        focus_area = (
            max(0, center_x - focus_width),
            max(0, center_y - focus_height),
            min(target_width, center_x + focus_width),
            min(target_height, center_y + focus_height)
        )
        
        # Çerçeve çiz ve bilgiler
        cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 0, 255), 3)
        cv2.putText(frame, f"HEDEF TESPIT EDILDI", (10, 30), cv2.FONT_HERSHEY_COMPLEX_SMALL, 0.8, (0, 255, 0), 1)
        cv2.putText(frame, f"Guven Puani: {conf:.2f}", (10, 50), cv2.FONT_HERSHEY_COMPLEX_SMALL, 0.8, (0, 255, 0), 1)
        cv2.putText(frame, f"DUTSTM Skoru: {best_score:.2f}", (10, 90), cv2.FONT_HERSHEY_COMPLEX_SMALL, 0.8, (0, 255, 0), 1)
        cv2.putText(frame, f"FPS: {fps}", (10, 70), cv2.FONT_HERSHEY_COMPLEX_SMALL, 0.8, (0, 255, 0), 1)
        
        # Kırmızı noktadan nesne merkezine yeşil çizgi çiz
        cv2.line(frame, frame_center, object_center, (0, 255, 0), 2, cv2.LINE_AA)
        
        # Odaklanma alanını görselleştir
        if focus_area:
            fx1, fy1, fx2, fy2 = focus_area
            cv2.rectangle(frame, (int(fx1), int(fy1)), (int(fx2), int(fy2)), (255, 0, 0), 2)
        
        # Hedefin merkeze göre göreceli konumu
        relative_x = object_center[0] - frame_center[0]
        relative_y = object_center[1] - frame_center[1]
        cv2.putText(frame, f"Hedef Konumu: {relative_x},{relative_y}", (10, 110),
                   cv2.FONT_HERSHEY_COMPLEX_SMALL, 0.8, (0, 255, 0), 1)
        
        # Hedef boyutu yüzdesi
        width_ratio = width / target_width
        height_ratio = height / target_height
        cv2.putText(frame, f"Hedef Boyutu: W:{width_ratio:.0%},H:{height_ratio:.0%}", (10, 130),
                   cv2.FONT_HERSHEY_COMPLEX_SMALL, 0.8, (0, 255, 0), 1)
        
        # Kilitlenme takibi (şartlar)
        if (
            target_left < object_center[0] < target_right
            and target_top < object_center[1] < target_bottom
            and (width / target_width >= required_area_ratio or height / target_height >= required_area_ratio)
        ):
            # Eğer bekleme süresi aktifse, kilitlenme başlatma
            if lock_cooldown_start_time and time.time() - lock_cooldown_start_time < lock_cooldown_duration:
                countdown_text = "BEKLENIYOR"
                cv2.putText(frame, countdown_text, ((target_left + target_right) // 2 - 100, target_top - 10),
                           cv2.FONT_HERSHEY_TRIPLEX, 0.8, (0, 255, 255), 1)
            else:
                if lock_start_time is None:
                    lock_start_time = time.time()
                    tracking_start_time = time.time()
                else:
                    elapsed_time = time.time() - lock_start_time
                    tracking_time = time.time() - tracking_start_time
                    countdown = lock_duration - elapsed_time
                    countdown_text = f"{max(countdown, 0):.0f}"
                    cv2.putText(frame, countdown_text, ((target_left + target_right) // 2, target_top - 10),
                               cv2.FONT_HERSHEY_TRIPLEX, 0.8, (0, 255, 255), 1)
                    cv2.putText(frame, f"Takip Suresi: {tracking_time:.2f}", (10, 170), 
                               cv2.FONT_HERSHEY_COMPLEX_SMALL, 0.8, (0, 255, 0), 1)
                    
                    if elapsed_time >= lock_duration:
                        successful_locks += 1
                        success_display_time = time.time()
                        lock_start_time = None
                        lock_cooldown_start_time = time.time()
                        
                        # Başarılı kilitlenilen hedefin merkez konumunu kaydet
                        locked_targets.add((object_center[0], object_center[1]))
                        
                        # Hedef takibini sıfırla - yeni hedef seçimine hazır ol
                        tracking_target_id = None
                        focus_area = None
        else:
            # Kilitlenme şartları bozulursa sadece sayaçları sıfırla
            lock_start_time = None
            # tracking_start_time'ı sıfırlama, takip devam ediyor
        
        # Başarılı kilitlenme yazısı
        if success_display_time and (time.time() - success_display_time <= 0.8):
            cv2.putText(frame, ">>>BASARILIYLA KILITLENILDI<<<", ((target_left + target_right) // 2 - 245, target_top + 25),
                       cv2.FONT_HERSHEY_COMPLEX_SMALL, 1.2, (0, 255, 0), 1)
        elif success_display_time and (time.time() - success_display_time > 1):
            success_display_time = None
    else:
        # Hedef kaybedildiyse, takibi sıfırla
        if tracking_target_id is not None:
            # Hedefi bir süre daha aramak için bir zamanlayıcı eklenebilir
            tracking_target_id = None
            focus_area = None
    
    # Başarılı kilitlenme sayısını göster
    cv2.putText(frame, f"Basarili Kilitlenme: {successful_locks}", (10, 190), 
               cv2.FONT_HERSHEY_COMPLEX_SMALL, 0.8, (0, 255, 0), 1)
    
    # Mevcut kilitlenilen hedef sayısını göster
    cv2.putText(frame, f"Farkli Hedef Sayisi: {len(locked_targets)}", (10, 210), 
               cv2.FONT_HERSHEY_COMPLEX_SMALL, 0.8, (0, 255, 0), 1)
    
    # Odaklanma modunu göster
    if focus_area:
        cv2.putText(frame, "ODAKLI TARAMA MODU", (target_width - 250, target_height - 20), 
                   cv2.FONT_HERSHEY_COMPLEX_SMALL, 0.8, (255, 0, 0), 1)
    else:
        cv2.putText(frame, "GENEL TARAMA MODU", (target_width - 250, target_height - 20), 
                   cv2.FONT_HERSHEY_COMPLEX_SMALL, 0.8, (0, 255, 0), 1)
    
    # Çerçeveyi göster
    cv2.imshow("Frame", frame)
    
    # Çıkış için 'q' tuşu
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Kaynakları serbest bırak
cap.release()
cv2.destroyAllWindows()